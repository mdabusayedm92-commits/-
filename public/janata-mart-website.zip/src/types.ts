export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
  verified?: boolean;
}

export interface Product {
  id: number;
  name: string;
  nameEn?: string;
  category: 'ইলেকট্রনিক্স' | 'ফ্যাশন' | 'কিচেন' | 'বিউটি' | 'গ্রোসারি';
  price: number;
  oldPrice?: number;
  unit: string;
  stock: number;
  desc: string;
  img: string;
  additionalImages?: string[];
  badges?: string[];
  rating: number;
  reviewsCount: number;
  reviews: Review[];
  featured?: boolean;
  warranty?: string;
  variants?: {
    colors?: string[];
    sizes?: string[];
  };
}

export interface CartItem extends Product {
  qty: number;
  selectedColor?: string;
  selectedSize?: string;
}

export interface UserProfile {
  name: string;
  phone: string;
  division: string;
  district: string;
  upazila: string;
  address: string;
  email?: string;
}

export type PaymentMethod = 'COD' | 'bKash' | 'Nagad' | 'Rocket' | 'Card';

export interface PaymentDetails {
  method: PaymentMethod;
  trxId?: string;
  accountNumber?: string;
  status: 'PAID' | 'PENDING' | 'VERIFIED';
  gatewayFee?: number;
  cardLast4?: string;
  paidAt?: string;
}

export type OrderStatus = 'পেন্ডিং' | 'প্রসেসিং' | 'শিপড' | 'ডেলিভার্ড' | 'বাতিল';

export interface Order {
  orderId: string;
  date: string;
  timestamp: number;
  name: string;
  phone: string;
  email?: string;
  location: string;
  division: string;
  district: string;
  upazila: string;
  address: string;
  paymentDetails: PaymentDetails;
  items: CartItem[];
  subtotal: number;
  deliveryCharge: number;
  discount: number;
  couponCode?: string;
  total: number;
  status: OrderStatus;
  deliveryEstimatedDate: string;
}

export interface Coupon {
  code: string;
  discountPercent?: number;
  discountAmount?: number;
  minSpend: number;
  description: string;
}
