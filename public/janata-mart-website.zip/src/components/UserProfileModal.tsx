import React, { useState } from 'react';
import { 
  X, 
  User, 
  Phone, 
  MapPin, 
  Check, 
  LogOut, 
  Package, 
  Sparkles,
  ShoppingCart,
  Heart
} from 'lucide-react';
import { UserProfile } from '../types';
import { BD_LOCATIONS, playSound, toBengaliNumber } from '../data/bangladeshData';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onSaveProfile: (profile: UserProfile) => void;
  onLogout: () => void;
  onOpenOrders: () => void;
  onOpenCart?: () => void;
  onOpenWishlist?: () => void;
  cartCount?: number;
  wishlistCount?: number;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSaveProfile,
  onLogout,
  onOpenOrders,
  onOpenCart,
  onOpenWishlist,
  cartCount = 0,
  wishlistCount = 0
}) => {
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [division, setDivision] = useState(currentUser?.division || 'ঢাকা');
  const [district, setDistrict] = useState(currentUser?.district || 'ঢাকা');
  const [upazila, setUpazila] = useState(currentUser?.upazila || 'মিরপুর');
  const [address, setAddress] = useState(currentUser?.address || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDivisionChange = (newDiv: string) => {
    setDivision(newDiv);
    const districts = BD_LOCATIONS[newDiv] ? Object.keys(BD_LOCATIONS[newDiv]) : [];
    if (districts.length > 0) {
      setDistrict(districts[0]);
      const upazilas = BD_LOCATIONS[newDiv][districts[0]] || [];
      setUpazila(upazilas[0] || '');
    } else {
      setDistrict('');
      setUpazila('');
    }
  };

  const handleDistrictChange = (newDist: string) => {
    setDistrict(newDist);
    const upazilas = (BD_LOCATIONS[division] && BD_LOCATIONS[division][newDist]) || [];
    setUpazila(upazilas[0] || '');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      alert('দয়া করে আপনার নাম ও মোবাইল নম্বর লিখুন।');
      return;
    }

    onSaveProfile({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      division,
      district,
      upazila,
      address: address.trim()
    });

    playSound('success');
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {currentUser ? 'গ্রাহক প্রোফাইল' : 'অ্যাকাউন্ট খুলুন / লগইন'}
              </h2>
              <span className="text-xs text-slate-500">স্বয়ংক্রিয় দ্রুত চেকআউটের সুবিধা পান</span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {savedSuccess && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>আপনার প্রোফাইল তথ্য সফলভাবে সংরক্ষিত হয়েছে!</span>
            </div>
          )}

          {currentUser ? (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-slate-900">{currentUser.name}</h3>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> সক্রিয় গ্রাহক
                  </span>
                </div>
                <div className="text-xs text-slate-600 flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono">{currentUser.phone}</span>
                </div>
                <div className="text-xs text-slate-600 flex items-start gap-2 pt-1 border-t border-slate-200/60">
                  <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                  <span>{currentUser.address}, {currentUser.upazila}, {currentUser.district}, {currentUser.division}</span>
                </div>
              </div>

              {/* Quick Actions Grid */}
              <div className="grid grid-cols-2 gap-2">
                {onOpenCart && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenCart();
                    }}
                    className="py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-rose-200"
                  >
                    <ShoppingCart className="w-4 h-4 text-rose-600" />
                    <span>আমার কার্ট ({toBengaliNumber(cartCount)})</span>
                  </button>
                )}

                {onOpenWishlist && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenWishlist();
                    }}
                    className="py-2.5 px-3 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-slate-200"
                  >
                    <Heart className="w-4 h-4 text-rose-500" />
                    <span>উইশলিস্ট ({toBengaliNumber(wishlistCount)})</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenOrders();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Package className="w-4 h-4" />
                  <span>অর্ডার ট্র্যাকিং</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onLogout();
                    playSound('click');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>লগআউট</span>
                </button>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-700 block mb-3">তথ্য পরিবর্তন করুন:</span>
              </div>
            </div>
          ) : null}

          {/* Form */}
          <form onSubmit={handleSave} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">পূর্ণ নাম *</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="যেমন: তানভীর আহমেদ"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">মোবাইল নম্বর *</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ইমেইল (ঐচ্ছিক)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@example.com"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">বিভাগ</label>
                <select
                  value={division}
                  onChange={(e) => handleDivisionChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                >
                  {Object.keys(BD_LOCATIONS).map((div) => (
                    <option key={div} value={div}>{div}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">জেলা</label>
                <select
                  value={district}
                  onChange={(e) => handleDistrictChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                >
                  {division && BD_LOCATIONS[division] && Object.keys(BD_LOCATIONS[division]).map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">থানা / উপজেলা</label>
              <select
                value={upazila}
                onChange={(e) => setUpazila(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
              >
                {division && district && BD_LOCATIONS[division] && BD_LOCATIONS[division][district] && 
                  BD_LOCATIONS[division][district].map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))
                }
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">বাসার ঠিকানা</label>
              <textarea
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="বাসা নম্বর, রোড, এলাকা..."
                rows={2}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              তথ্য সংরক্ষণ করুন
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
