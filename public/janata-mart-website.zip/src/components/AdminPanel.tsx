import React, { useState } from 'react';
import { 
  PlusCircle, 
  Trash2, 
  Package, 
  TrendingUp, 
  ShoppingBag, 
  AlertTriangle, 
  Check, 
  Store, 
  RefreshCw, 
  Search, 
  Tag,
  Download
} from 'lucide-react';
import { Product, Order, OrderStatus, Coupon } from '../types';
import { toBengaliNumber, playSound } from '../data/bangladeshData';

interface AdminPanelProps {
  products: Product[];
  orders: Order[];
  coupons: Coupon[];
  onBackToStore: () => void;
  onAddProduct: (product: Omit<Product, 'id' | 'rating' | 'reviewsCount' | 'reviews'>) => void;
  onDeleteProduct: (productId: number) => void;
  onUpdateStock: (productId: number, newStock: number) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onResetData: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  products,
  orders,
  coupons,
  onBackToStore,
  onAddProduct,
  onDeleteProduct,
  onUpdateStock,
  onUpdateOrderStatus,
  onResetData
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'add' | 'orders' | 'coupons'>('products');
  const [productSearch, setProductSearch] = useState('');
  
  // New Product Form State
  const [pName, setPName] = useState('');
  const [pNameEn, setPNameEn] = useState('');
  const [pCategory, setPCategory] = useState<'বিউটি' | 'ইলেকট্রনিক্স' | 'ফ্যাশন' | 'কিচেন' | 'গ্রোসারি'>('ইলেকট্রনিক্স');
  const [pPrice, setPPrice] = useState<number>(500);
  const [pOldPrice, setPOldPrice] = useState<number>(650);
  const [pUnit, setPUnit] = useState('১ পিস');
  const [pStock, setPStock] = useState<number>(25);
  const [pDesc, setPDesc] = useState('');
  const [pImg, setPImg] = useState('https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=700&q=80');
  const [pWarranty, setPWarranty] = useState('১ বছরের অফিসিয়াল ওয়ারেন্টি');

  // Stats calculation
  const totalSales = orders.filter(o => o.status !== 'বাতিল').reduce((sum, o) => sum + o.total, 0);
  const lowStockCount = products.filter(p => p.stock <= 5).length;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pName.trim()) {
      alert('পণ্যের নাম আবশ্যক');
      return;
    }

    onAddProduct({
      name: pName.trim(),
      nameEn: pNameEn.trim(),
      category: pCategory,
      price: Number(pPrice),
      oldPrice: pOldPrice ? Number(pOldPrice) : undefined,
      unit: pUnit.trim() || '১ পিস',
      stock: Number(pStock) || 10,
      desc: pDesc.trim() || 'উচ্চমানের প্রিমিয়াম পণ্য। দ্রুত হোম ডেলিভারি সুবিধা।',
      img: pImg.trim() || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=700&q=80',
      warranty: pWarranty.trim()
    });

    playSound('success');
    setPName('');
    setPNameEn('');
    setPDesc('');
    setActiveTab('products');
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(productSearch.toLowerCase()) || 
    p.category.includes(productSearch)
  );

  return (
    <div className="min-h-screen bg-slate-50 py-6 px-4 sm:px-8">
      <div className="container mx-auto max-w-6xl">
        
        {/* Top Header Bar */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl font-black text-slate-900">জনতা মার্ট এডমিন প্যানেল</span>
              <span className="text-[10px] bg-rose-100 text-rose-700 font-bold px-2 py-0.5 rounded-full">PRO CONTROL</span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">দোকানের স্টক, অর্ডার ও বিক্রয় মনিটরিং ব্যবস্থা</p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={async (e) => {
                e.preventDefault();
                try {
                  const res = await fetch('/janata-mart-website.zip');
                  const blob = await res.blob();
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'janata-mart-website.zip';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  setTimeout(() => window.URL.revokeObjectURL(url), 2000);
                } catch {
                  window.location.href = '/janata-mart-website.zip';
                }
              }}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all hover:scale-105 cursor-pointer"
              title="সম্পূর্ণ প্রজেক্টের জিপ ফাইল ডাউনলোড করুন"
            >
              <Download className="w-3.5 h-3.5" /> জিপ ডাউনলোড
            </button>

            <button
              onClick={() => {
                if (confirm('ডেমো ডেটা রিসেট করতে চান? এতে নতুন যুক্ত করা আইটেম রিসেট হবে।')) {
                  onResetData();
                }
              }}
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" /> রিসেট
            </button>

            <button
              onClick={onBackToStore}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <Store className="w-4 h-4" /> স্টোরে ফিরুন
            </button>
          </div>
        </div>

        {/* Analytics Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">মোট বিক্রয়</span>
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">
              ৳{toBengaliNumber(totalSales)}
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold block mt-1">সব সফল অর্ডার মিলিয়ে</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">মোট অর্ডার</span>
              <Package className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">
              {toBengaliNumber(orders.length)}টি
            </div>
            <span className="text-[10px] text-slate-500 font-medium block mt-1">
              পেন্ডিং: {toBengaliNumber(orders.filter(o => o.status === 'পেন্ডিং').length)}টি
            </span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">মোট পণ্য</span>
              <ShoppingBag className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">
              {toBengaliNumber(products.length)}টি
            </div>
            <span className="text-[10px] text-slate-500 font-medium block mt-1">৫টি ক্যাটাগরিতে</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">স্টক সতর্কতা</span>
              <AlertTriangle className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-amber-600">
              {toBengaliNumber(lowStockCount)}টি
            </div>
            <span className="text-[10px] text-amber-600 font-semibold block mt-1">৫ বা তার কম স্টক</span>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex gap-2 overflow-x-auto pb-3 mb-4 text-xs font-bold">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'products'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            পণ্য তালিকা ({toBengaliNumber(products.length)})
          </button>

          <button
            onClick={() => setActiveTab('add')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'add'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <PlusCircle className="w-4 h-4 text-rose-500" /> নতুন পণ্য যোগ
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            অর্ডারসমূহ ({toBengaliNumber(orders.length)})
          </button>

          <button
            onClick={() => setActiveTab('coupons')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'coupons'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            কুপন কোডস ({toBengaliNumber(coupons.length)})
          </button>
        </div>

        {/* TAB 1: PRODUCT LIST */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="পণ্য বা ক্যাটাগরি ফিল্টার করুন..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <button
                onClick={() => setActiveTab('add')}
                className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" /> নতুন পণ্য
              </button>
            </div>

            <div className="divide-y divide-slate-100 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100 pb-2">
                    <th className="py-2">পণ্য</th>
                    <th className="py-2">ক্যাটাগরি</th>
                    <th className="py-2">মূল্য</th>
                    <th className="py-2">স্টক সংখ্যা</th>
                    <th className="py-2 text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 pr-3">
                        <div className="flex items-center gap-3">
                          <img src={p.img} alt={p.name} className="w-12 h-12 rounded-xl object-cover border shrink-0 bg-slate-50" />
                          <div>
                            <div className="font-bold text-slate-900">{p.name}</div>
                            <div className="text-[10px] text-slate-400">{p.unit}</div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-2">
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 font-semibold text-[10px] text-slate-700">
                          {p.category}
                        </span>
                      </td>

                      <td className="py-3 px-2 font-bold text-rose-600">
                        ৳{toBengaliNumber(p.price)}
                      </td>

                      <td className="py-3 px-2">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="number"
                            min={0}
                            value={p.stock}
                            onChange={(e) => onUpdateStock(p.id, Number(e.target.value))}
                            className="w-16 px-2 py-1 border border-slate-300 rounded-lg text-xs font-bold text-center"
                          />
                          {p.stock <= 5 && (
                            <span className="text-[10px] text-amber-600 font-bold bg-amber-50 px-1.5 py-0.5 rounded">
                              স্বল্প স্টক
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 pl-2 text-right">
                        <button
                          onClick={() => {
                            if (confirm(`'${p.name}' পণ্যটি কি নিশ্চিতভাবে ডিলিট করতে চান?`)) {
                              onDeleteProduct(p.id);
                              playSound('trash');
                            }
                          }}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="পণ্য মুছুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: ADD NEW PRODUCT FORM */}
        {activeTab === 'add' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm max-w-2xl mx-auto">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3 mb-5">
              নতুন পণ্য তালিকাভুক্ত করুন
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">পণ্যের নাম (বাংলা) *</label>
                <input
                  type="text"
                  value={pName}
                  onChange={(e) => setPName(e.target.value)}
                  placeholder="যেমন: ওয়্যারলেস মিনি পাওয়ার ব্যাংক"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ইংরেজি নাম (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    value={pNameEn}
                    onChange={(e) => setPNameEn(e.target.value)}
                    placeholder="Wireless Mini Power Bank"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ক্যাটাগরি *</label>
                  <select
                    value={pCategory}
                    onChange={(e) => setPCategory(e.target.value as 'বিউটি' | 'ইলেকট্রনিক্স' | 'ফ্যাশন' | 'কিচেন' | 'গ্রোসারি')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  >
                    <option value="ইলেকট্রনিক্স">ইলেকট্রনিক্স</option>
                    <option value="বিউটি">বিউটি ও কেয়ার</option>
                    <option value="ফ্যাশন">ফ্যাশন ও পোশাক</option>
                    <option value="কিচেন">হোম ও কিচেন</option>
                    <option value="গ্রোসারি">গ্রোসারি ও খাদ্য</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">বিক্রয় মূল্য (৳) *</label>
                  <input
                    type="number"
                    value={pPrice}
                    onChange={(e) => setPPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">পূর্বের মূল্য (৳)</label>
                  <input
                    type="number"
                    value={pOldPrice}
                    onChange={(e) => setPOldPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">পরিমাণ / ইউনিট</label>
                  <input
                    type="text"
                    value={pUnit}
                    onChange={(e) => setPUnit(e.target.value)}
                    placeholder="১ পিস / ১০০ গ্রাম"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">স্টক সংখ্যা</label>
                  <input
                    type="number"
                    value={pStock}
                    onChange={(e) => setPStock(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ছবির URL (ইন্টারনেট লিংক)</label>
                <input
                  type="url"
                  value={pImg}
                  onChange={(e) => setPImg(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
                {pImg && (
                  <div className="mt-2 flex items-center gap-2">
                    <img src={pImg} alt="Preview" className="w-12 h-12 rounded-lg object-cover border" />
                    <span className="text-[10px] text-slate-400">ছবির প্রিভিউ</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ওয়ারেন্টি বা গ্যারান্টি তথ্য</label>
                <input
                  type="text"
                  value={pWarranty}
                  onChange={(e) => setPWarranty(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">পণ্যের বিস্তারিত গুণাগুণ (Description)</label>
                <textarea
                  value={pDesc}
                  onChange={(e) => setPDesc(e.target.value)}
                  rows={3}
                  placeholder="পণ্যটির বিশেষত্ব, ব্যবহার পদ্ধতি ইত্যাদি..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
              >
                পণ্য সংরক্ষণ করুন
              </button>
            </form>
          </div>
        )}

        {/* TAB 3: ORDERS MANAGEMENT */}
        {activeTab === 'orders' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              অর্ডার তালিকা ও অগ্রগতি
            </h3>

            {orders.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-10">কোনো অর্ডার পাওয়া যায়নি।</p>
            ) : (
              <div className="space-y-3">
                {orders.map((o) => (
                  <div key={o.orderId} className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-colors">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm text-slate-900">{o.orderId}</span>
                        <span className="text-[10px] text-slate-400">{o.date}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500">স্ট্যাটাস:</span>
                        <select
                          value={o.status}
                          onChange={(e) => onUpdateOrderStatus(o.orderId, e.target.value as OrderStatus)}
                          className="px-2.5 py-1 rounded-lg border border-slate-300 text-xs font-bold bg-white focus:outline-none"
                        >
                          <option value="পেন্ডিং">পেন্ডিং</option>
                          <option value="প্রসেসিং">প্রসেসিং</option>
                          <option value="শিপড">শিপড (কুরিয়ার)</option>
                          <option value="ডেলিভার্ড">ডেলিভার্ড</option>
                          <option value="বাতিল">বাতিল</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-600">
                      <div>
                        <span className="font-semibold text-slate-900 block">{o.name}</span>
                        <span className="font-mono text-slate-500">{o.phone}</span>
                      </div>

                      <div>
                        <span className="text-slate-500 block">ডেলিভারি ঠিকানা:</span>
                        <span>{o.address}, {o.upazila}, {o.district}</span>
                      </div>

                      <div>
                        <span className="text-slate-500 block">পেমেন্ট:</span>
                        <span className="font-bold text-slate-900">{o.paymentDetails.method}</span>
                        {o.paymentDetails.trxId && (
                          <span className="text-[10px] font-mono text-emerald-600 block">
                            TrxID: {o.paymentDetails.trxId}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-slate-500">আইটেম সংখ্যা: {toBengaliNumber(o.items.length)}টি</span>
                      <span className="font-black text-rose-600 text-sm">
                        মোট: ৳{toBengaliNumber(o.total)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: COUPONS */}
        {activeTab === 'coupons' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              সক্রিয় প্রোমোকোডসমূহ
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {coupons.map((c) => (
                <div key={c.code} className="p-4 rounded-2xl border-2 border-dashed border-rose-300 bg-rose-50/40">
                  <div className="flex items-center gap-1.5 font-mono font-black text-rose-600 text-sm mb-1">
                    <Tag className="w-4 h-4" />
                    {c.code}
                  </div>
                  <p className="text-xs text-slate-600 mb-2">{c.description}</p>
                  <span className="text-[10px] text-slate-400 font-semibold block">
                    সর্বনিম্ন অর্ডার: ৳{toBengaliNumber(c.minSpend)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
