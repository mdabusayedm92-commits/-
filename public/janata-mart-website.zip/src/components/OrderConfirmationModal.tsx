import React, { useEffect, useState } from 'react';
import { 
  CheckCircle2, 
  Printer, 
  ShoppingBag, 
  Truck, 
  MapPin, 
  Phone, 
  Calendar, 
  X,
  Copy,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Order } from '../types';
import { toBengaliNumber, playSound } from '../data/bangladeshData';

interface OrderConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onTrackOrder: (orderId: string) => void;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  isOpen,
  onClose,
  order,
  onTrackOrder
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen && order) {
      setCopied(false);
      playSound('success');
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // Safe fallback
      }
    }
  }, [isOpen, order]);

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyTracking = () => {
    if (!order) return;
    navigator.clipboard?.writeText(order.orderId);
    playSound('pop');
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-6 text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-3 shadow-lg animate-bounce">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <span className="text-xs font-bold uppercase tracking-wider text-emerald-100 block mb-1">
            ধন্যবাদ আপনার কেনাকাটায়!
          </span>
          <h2 className="text-xl sm:text-2xl font-black">অর্ডার সফলভাবে গৃহীত হয়েছে</h2>
          
          {/* Tracking Number with Quick Copy */}
          <div className="mt-3 inline-flex items-center gap-2 bg-black/20 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/20 text-xs">
            <span>ট্র্যাকিং নম্বর:</span>
            <strong className="font-mono text-sm tracking-wider">{order.orderId}</strong>
            <button
              onClick={handleCopyTracking}
              className="ml-1 px-2.5 py-0.5 rounded-full bg-white text-emerald-800 hover:bg-emerald-100 font-bold text-[11px] flex items-center gap-1 transition-transform active:scale-95 cursor-pointer shadow-sm"
              title="ট্র্যাকিং নম্বর কপি করুন"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-emerald-800" />}
              <span>{copied ? 'কপি হয়েছে!' : 'কপি করুন'}</span>
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div id="printable-receipt" className="p-6 space-y-4 text-xs text-slate-700">
          
          {/* Interactive Copy Tracking Banner */}
          <div className="p-3 bg-emerald-50/80 border border-emerald-200 rounded-2xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-emerald-700 font-bold uppercase block">অর্ডার / ট্র্যাকিং নম্বর</span>
              <div className="font-mono text-sm font-black text-emerald-900">{order.orderId}</div>
            </div>
            <button
              onClick={handleCopyTracking}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-transform active:scale-95 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'কপি সম্পন্ন!' : 'নম্বর কপি করুন'}</span>
            </button>
          </div>
          
          {/* Janata Mart Header on Print */}
          <div className="border-b border-slate-200 pb-3 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 p-0.5 flex items-center justify-center shrink-0">
                <img 
                  src="/assets/aistudio/file_00000000288c81f4911ee1105a435626_6f285ce8.png" 
                  alt="জনতা মার্ট" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <span className="text-base font-black text-rose-600 block leading-tight">জনতা মার্ট (Janata Mart)</span>
                <p className="text-[11px] text-slate-400">বাংলাদেশের বিশ্বস্ত অনলাইন শপিং</p>
              </div>
            </div>
            <div className="text-right">
              <span className="font-mono font-bold text-slate-900 block">{order.orderId}</span>
              <span className="text-[10px] text-slate-400">{order.date}</span>
            </div>
          </div>

          {/* Delivery & Payment Badges */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">পেমেন্ট মেথড</span>
              <span className="font-bold text-slate-900 block text-xs">
                {order.paymentDetails.method === 'COD' ? 'ক্যাশ অন ডেলিভারি' : `${order.paymentDetails.method} (অনলাইন পেমেন্ট)`}
              </span>
              {order.paymentDetails.trxId && (
                <span className="text-[10px] font-mono text-emerald-600 font-bold block mt-0.5">
                  TrxID: {order.paymentDetails.trxId}
                </span>
              )}
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">আনুমানিক ডেলিভারি</span>
              <span className="font-bold text-emerald-600 flex items-center gap-1">
                <Truck className="w-3.5 h-3.5" />
                {order.deliveryEstimatedDate}
              </span>
              <span className="text-[10px] text-slate-400">২৪-৪৮ ঘণ্টার ভেতর</span>
            </div>
          </div>

          {/* Customer & Address Details */}
          <div className="space-y-1.5 p-3 rounded-2xl bg-white border border-slate-200">
            <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">ডেলিভারি ঠিকানা</span>
            <div className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
              <span>{order.name}</span>
              <span className="text-slate-400 font-normal">|</span>
              <span className="font-mono text-slate-600 flex items-center gap-1"><Phone className="w-3 h-3" /> {order.phone}</span>
            </div>
            <div className="text-slate-600 flex items-start gap-1 pt-0.5">
              <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
              <span>{order.address}, {order.upazila}, {order.district}, {order.division}</span>
            </div>
          </div>

          {/* Order Items Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden">
            <div className="bg-slate-100/70 px-3 py-2 text-[11px] font-bold text-slate-600 flex justify-between">
              <span>পণ্যের বিবরণ</span>
              <span>মূল্য</span>
            </div>
            <div className="divide-y divide-slate-100">
              {order.items.map((item, i) => (
                <div key={i} className="p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img src={item.img} alt={item.name} className="w-10 h-10 rounded-lg object-cover bg-slate-50 border shrink-0" />
                    <div>
                      <span className="font-bold text-slate-800 line-clamp-1">{item.name}</span>
                      <span className="text-[10px] text-slate-400">
                        ৳{toBengaliNumber(item.price)} × {toBengaliNumber(item.qty)}টি ({item.unit})
                      </span>
                    </div>
                  </div>
                  <span className="font-bold text-slate-800 shrink-0">
                    ৳{toBengaliNumber(item.price * item.qty)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Bill Calculation Summary */}
          <div className="space-y-1.5 pt-1">
            <div className="flex justify-between text-slate-600">
              <span>সাবটোটাল:</span>
              <span>৳{toBengaliNumber(order.subtotal)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>ডেলিভারি চার্জ:</span>
              <span>{order.deliveryCharge === 0 ? 'ফ্রি' : `৳${toBengaliNumber(order.deliveryCharge)}`}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>কুপন ছাড় ({order.couponCode}):</span>
                <span>-৳{toBengaliNumber(order.discount)}</span>
              </div>
            )}
            <div className="border-t border-slate-200 pt-2 flex justify-between font-black text-sm text-rose-600">
              <span>সর্বমোট প্রদেয় বিল:</span>
              <span>৳{toBengaliNumber(order.total)}</span>
            </div>
          </div>

        </div>

        {/* Modal Action Buttons */}
        <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap gap-2.5">
          <button
            onClick={handlePrint}
            className="flex-1 py-2.5 px-3 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            রশিদ প্রিন্ট করুন
          </button>

          <button
            onClick={() => {
              onClose();
              onTrackOrder(order.orderId);
            }}
            className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5" />
            অর্ডার ট্র্যাক করুন
          </button>

          <button
            onClick={onClose}
            className="w-full py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            আরো কেনাকাটা চালিয়ে যান
          </button>
        </div>

      </div>
    </div>
  );
};
