import React from 'react';
import { X, Heart, Trash2, ShoppingCart } from 'lucide-react';
import { Product } from '../types';
import { toBengaliNumber, playSound } from '../data/bangladeshData';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds: number[];
  allProducts: Product[];
  onRemoveFromWishlist: (productId: number) => void;
  onAddToCart: (product: Product) => void;
  onOpenDetails: (product: Product) => void;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  allProducts,
  onRemoveFromWishlist,
  onAddToCart,
  onOpenDetails
}) => {
  if (!isOpen) return null;

  const wishedProducts = allProducts.filter(p => wishlistIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8 flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
              <Heart className="w-5 h-5 fill-rose-600 text-rose-600" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">পছন্দের তালিকা (উইশলিস্ট)</h2>
              <span className="text-xs text-slate-500">{toBengaliNumber(wishedProducts.length)}টি সংরক্ষিত পণ্য</span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* List Content */}
        <div className="p-5 overflow-y-auto flex-1">
          {wishedProducts.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-16 h-16 rounded-full bg-rose-50 flex items-center justify-center text-rose-400 mx-auto">
                <Heart className="w-8 h-8" />
              </div>
              <p className="text-xs text-slate-500">আপনার পছন্দের তালিকায় কোনো পণ্য নেই।</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {wishedProducts.map(prod => (
                <div key={prod.id} className="py-3 flex items-center gap-3">
                  <img 
                    src={prod.img} 
                    alt={prod.name}
                    onClick={() => {
                      onClose();
                      onOpenDetails(prod);
                    }}
                    className="w-14 h-14 rounded-xl object-cover bg-slate-50 border cursor-pointer shrink-0" 
                  />

                  <div 
                    className="flex-1 min-w-0 cursor-pointer"
                    onClick={() => {
                      onClose();
                      onOpenDetails(prod);
                    }}
                  >
                    <h4 className="text-xs font-bold text-slate-800 truncate hover:text-rose-600">{prod.name}</h4>
                    <span className="text-[10px] text-slate-400 block">{prod.category}</span>
                    <span className="text-xs font-black text-rose-600">৳{toBengaliNumber(prod.price)}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        playSound('pop');
                        onAddToCart(prod);
                      }}
                      className="p-2 rounded-xl bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white transition-colors cursor-pointer"
                      title="কার্টে যোগ করুন"
                    >
                      <ShoppingCart className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        playSound('trash');
                        onRemoveFromWishlist(prod.id);
                      }}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors cursor-pointer"
                      title="মুছুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
