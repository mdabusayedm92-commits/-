import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  X, 
  Lock, 
  ArrowRight, 
  CreditCard, 
  CheckCircle2, 
  Smartphone, 
  QrCode, 
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import { PaymentMethod, PaymentDetails } from '../types';
import { toBengaliNumber } from '../data/bangladeshData';

interface PaymentGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  method: PaymentMethod;
  amount: number;
  orderNumber: string;
  customerPhone: string;
  customerName: string;
  onPaymentSuccess: (paymentDetails: PaymentDetails) => void;
}

export const PaymentGatewayModal: React.FC<PaymentGatewayModalProps> = ({
  isOpen,
  onClose,
  method,
  amount,
  orderNumber,
  customerPhone,
  customerName,
  onPaymentSuccess
}) => {
  // bKash & Nagad & Rocket Steps: 1 = Account Phone, 2 = OTP, 3 = PIN, 4 = Processing
  const [step, setStep] = useState<number>(1);
  const [phoneNumber, setPhoneNumber] = useState<string>(customerPhone || '01711002233');
  const [otp, setOtp] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [otpTimer, setOtpTimer] = useState<number>(30);
  
  // Card states
  const [cardNumber, setCardNumber] = useState<string>('4242 4242 4242 4242');
  const [cardExpiry, setCardExpiry] = useState<string>('12/28');
  const [cardCvv, setCardCvv] = useState<string>('789');
  const [cardHolder, setCardHolder] = useState<string>(customerName || 'JANATA CUSTOMER');
  
  // QR state
  const [showQrTab, setShowQrTab] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setStep(1);
      setPhoneNumber(customerPhone || '01711002233');
      setOtp('');
      setPin('');
      setIsProcessing(false);
      setErrorMsg('');
      setOtpTimer(30);
      setShowQrTab(false);
    }
  }, [isOpen, customerPhone]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === 2 && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [step, otpTimer]);

  if (!isOpen) return null;

  // Handle Steps
  const handleProceedToOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const cleaned = phoneNumber.replace(/\s+/g, '');
    if (!cleaned.startsWith('01') || cleaned.length !== 11) {
      setErrorMsg('সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)');
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep(2);
      setOtpTimer(30);
    }, 600);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (otp.length < 4) {
      setErrorMsg('সঠিক ৪ বা ৬ ডিজিটের ভেরিফিকেশন কোড দিন');
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep(3);
    }, 500);
  };

  const handleConfirmPin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (pin.length < 4) {
      setErrorMsg('সঠিক পিন (PIN) নম্বর দিন');
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const prefix = method === 'bKash' ? 'BK' : method === 'Nagad' ? 'NG' : method === 'Rocket' ? 'RK' : 'TX';
      const randomTrx = prefix + Math.random().toString(36).substring(2, 9).toUpperCase();
      
      onPaymentSuccess({
        method,
        accountNumber: phoneNumber,
        trxId: randomTrx,
        status: 'PAID',
        paidAt: new Date().toLocaleTimeString('bn-BD')
      });
    }, 1200);
  };

  const handleCardPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (cardNumber.replace(/\s/g, '').length < 15) {
      setErrorMsg('সঠিক ১৬ ডিজিট কার্ড নম্বর দিন');
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const randomTrx = 'SSL' + Math.random().toString(36).substring(2, 9).toUpperCase();
      onPaymentSuccess({
        method: 'Card',
        cardLast4: cardNumber.replace(/\s/g, '').slice(-4),
        trxId: randomTrx,
        status: 'PAID',
        paidAt: new Date().toLocaleTimeString('bn-BD')
      });
    }, 1400);
  };

  // Theme colors based on Gateway
  const isBkash = method === 'bKash';
  const isNagad = method === 'Nagad';
  const isRocket = method === 'Rocket';
  const isCard = method === 'Card';

  const brandColor = isBkash ? '#E2136E' : isNagad ? '#F7941D' : isRocket ? '#8c338f' : '#2563EB';
  const brandName = isBkash ? 'বিকাশ (bKash)' : isNagad ? 'নগদ (Nagad)' : isRocket ? 'রকেট (Rocket)' : 'কার্ড / ইন্টারনেট ব্যাংকিং';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
        
        {/* Gateway Branded Header */}
        <div 
          className="text-white p-5 flex items-center justify-between transition-colors"
          style={{ backgroundColor: brandColor }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center font-bold text-xl shadow-inner">
              {isBkash && <span>b</span>}
              {isNagad && <span>ন</span>}
              {isRocket && <span>R</span>}
              {isCard && <CreditCard className="w-5 h-5 text-white" />}
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider font-semibold opacity-90 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                সুরক্ষিত গেটওয়ে | 256-Bit SSL
              </div>
              <h2 className="text-lg font-bold leading-tight">{brandName}</h2>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Invoice Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-3 flex items-center justify-between text-xs text-slate-600">
          <div>
            <span className="font-semibold text-slate-900">মার্চেন্ট:</span> জনতা মার্ট ই-কমার্স
          </div>
          <div className="text-right">
            <span className="font-semibold text-slate-900">প্রদেয় বিল:</span>
            <span className="ml-1 text-sm font-bold text-rose-600">৳{toBengaliNumber(amount)}</span>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* CARD PAYMENT FLOW */}
          {isCard ? (
            <form onSubmit={handleCardPayment} className="space-y-4">
              {/* Virtual Card Graphic */}
              <div className="w-full h-44 rounded-2xl bg-gradient-to-tr from-slate-900 via-indigo-950 to-blue-900 text-white p-5 shadow-lg flex flex-col justify-between relative overflow-hidden">
                <div className="absolute right-[-20px] top-[-20px] w-40 h-40 bg-white/5 rounded-full pointer-events-none" />
                <div className="flex justify-between items-center">
                  <span className="font-bold tracking-widest text-sm text-amber-300">JANATA PAY</span>
                  <div className="flex gap-1">
                    <div className="w-6 h-6 rounded-full bg-red-500 opacity-80" />
                    <div className="w-6 h-6 rounded-full bg-amber-400 opacity-80 -ml-3" />
                  </div>
                </div>

                <div className="font-mono text-base tracking-widest text-slate-200">
                  {cardNumber || '•••• •••• •••• ••••'}
                </div>

                <div className="flex justify-between items-end text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block">Card Holder</span>
                    <span className="font-semibold tracking-wide uppercase truncate max-w-[150px] block">{cardHolder}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase block">Expires</span>
                    <span className="font-mono font-semibold">{cardExpiry}</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">কার্ড নম্বর (Card Number)</label>
                <input 
                  type="text" 
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="xxxx xxxx xxxx xxxx"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">মেয়াদ (MM/YY)</label>
                  <input 
                    type="text" 
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(e.target.value)}
                    placeholder="12/28"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">CVV / CVC</label>
                  <input 
                    type="password" 
                    maxLength={4}
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value)}
                    placeholder="123"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">কার্ডধারীর নাম</label>
                <input 
                  type="text" 
                  value={cardHolder}
                  onChange={(e) => setCardHolder(e.target.value)}
                  placeholder="Md. Customer Name"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    পেমেন্ট প্রসেসিং হচ্ছে...
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    ৳{toBengaliNumber(amount)} পরিশোধ করুন
                  </>
                )}
              </button>
            </form>
          ) : (
            /* MFS (bKash / Nagad / Rocket) FLOW */
            <div>
              {/* Tab Selector: Account / Direct QR */}
              <div className="flex border-b border-slate-200 mb-5 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setShowQrTab(false)}
                  className={`flex-1 py-2 text-center border-b-2 flex items-center justify-center gap-1.5 ${
                    !showQrTab ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  একাউন্ট নম্বর দিয়ে পে
                </button>
                <button
                  type="button"
                  onClick={() => setShowQrTab(true)}
                  className={`flex-1 py-2 text-center border-b-2 flex items-center justify-center gap-1.5 ${
                    showQrTab ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <QrCode className="w-3.5 h-3.5" />
                  সরাসরি QR স্ক্যান
                </button>
              </div>

              {showQrTab ? (
                /* QR Scan Mode */
                <div className="text-center py-2 space-y-4">
                  <div className="p-4 bg-slate-50 border-2 border-dashed border-slate-300 rounded-2xl inline-block shadow-sm">
                    {/* Visual QR representation */}
                    <div className="w-44 h-44 bg-white p-2 border border-slate-200 rounded-xl flex flex-col items-center justify-center gap-2 relative">
                      <div className="grid grid-cols-4 gap-1.5 p-1">
                        <div className="w-7 h-7 bg-slate-900 rounded-sm" />
                        <div className="w-7 h-7 bg-slate-900 rounded-sm" />
                        <div className="w-7 h-7 border-4 border-slate-900 rounded-sm" />
                        <div className="w-7 h-7 bg-slate-900 rounded-sm" />
                        <div className="w-7 h-7 border-4 border-slate-900 rounded-sm" />
                        <div className="w-7 h-7 bg-slate-900 rounded-sm" />
                        <div className="w-7 h-7 bg-slate-900 rounded-sm" />
                        <div className="w-7 h-7 border-4 border-slate-900 rounded-sm" />
                      </div>
                      <div className="text-[10px] font-bold text-slate-500">
                        {isBkash ? 'bKash QR' : 'Nagad QR'} | ৳{amount}
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600">
                    আপনার <strong>{brandName}</strong> অ্যাপ খুলে উপরের QR কোডটি স্ক্যান করে দ্রুত পেমেন্ট সম্পন্ন করুন।
                  </p>
                  <button
                    onClick={() => {
                      setIsProcessing(true);
                      setTimeout(() => {
                        const randomTrx = (isBkash ? 'BK' : 'NG') + Math.random().toString(36).substring(2, 9).toUpperCase();
                        onPaymentSuccess({
                          method,
                          accountNumber: customerPhone,
                          trxId: randomTrx,
                          status: 'PAID',
                          paidAt: new Date().toLocaleTimeString('bn-BD')
                        });
                      }, 1000);
                    }}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition-all flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> স্ক্যান সম্পন্ন হয়েছে নিশ্চিত করুন
                  </button>
                </div>
              ) : (
                /* Standard Step Form */
                <>
                  {/* Step 1: Mobile Number */}
                  {step === 1 && (
                    <form onSubmit={handleProceedToOtp} className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          আপনার {brandName} একাউন্ট নম্বর দিন
                        </label>
                        <div className="relative">
                          <input 
                            type="tel" 
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            placeholder="01XXXXXXXXX"
                            maxLength={11}
                            className="w-full pl-3.5 pr-20 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono text-sm tracking-wider"
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setPhoneNumber('01711002233')}
                            className="absolute right-2 top-1.5 px-2 py-1 text-[10px] bg-slate-100 hover:bg-slate-200 rounded font-semibold text-slate-700"
                          >
                            টেস্ট নম্বর
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1.5">
                          অর্ডার ট্র্যাকিং ও কনফার্মেশনের জন্য নম্বরটি ব্যবহার করা হবে।
                        </p>
                      </div>

                      <div className="p-3 bg-rose-50/70 border border-rose-100 rounded-xl text-xs text-rose-900 leading-relaxed">
                        🔒 আপনার সুরক্ষায় {brandName} কখনই ফোন করে আপনার পাসওয়ার্ড বা পিন জানতে চাইবে না।
                      </div>

                      <button
                        type="submit"
                        disabled={isProcessing}
                        className="w-full py-3 rounded-xl text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                        style={{ backgroundColor: brandColor }}
                      >
                        {isProcessing ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            যাচাই করা হচ্ছে...
                          </>
                        ) : (
                          <>
                            পরবর্তী ধাপে যান
                            <ArrowRight className="w-4 h-4" />
                          </>
                        )}
                      </button>
                    </form>
                  )}

                  {/* Step 2: OTP Verification */}
                  {step === 2 && (
                    <form onSubmit={handleVerifyOtp} className="space-y-4 animate-in fade-in">
                      <div className="text-center pb-1">
                        <span className="text-xs text-slate-600 block">
                          <strong>{phoneNumber}</strong> নম্বরে একটি ভেরিফিকেশন কোড (OTP) পাঠানো হয়েছে:
                        </span>
                      </div>

                      <div>
                        <div className="relative">
                          <input 
                            type="text" 
                            value={otp}
                            onChange={(e) => setOtp(e.target.value)}
                            placeholder="যেমন: 123456"
                            maxLength={6}
                            className="w-full text-center tracking-widest text-lg font-mono py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500"
                            required
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => setOtp('123456')}
                            className="absolute right-2 top-2 px-2 py-1 text-[10px] bg-emerald-100 text-emerald-800 rounded font-semibold"
                          >
                            অটো-ফিল (123456)
                          </button>
                        </div>
                      </div>

                      <div className="flex justify-between items-center text-xs text-slate-500">
                        <span>
                          {otpTimer > 0 ? (
                            `পুনরায় কোড পাঠান (${otpTimer} সেকেন্ড)`
                          ) : (
                            <button 
                              type="button" 
                              onClick={() => setOtpTimer(30)}
                              className="text-rose-600 hover:underline font-semibold"
                            >
                              কোড পুনরায় পাঠান
                            </button>
                          )}
                        </span>
                        <button 
                          type="button" 
                          onClick={() => setStep(1)}
                          className="text-slate-600 hover:underline"
                        >
                          নম্বর পরিবর্তন
                        </button>
                      </div>

                      <button
                        type="submit"
                        disabled={isProcessing}
                        className="w-full py-3 rounded-xl text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                        style={{ backgroundColor: brandColor }}
                      >
                        {isProcessing ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            কোড যাচাই হচ্ছে...
                          </>
                        ) : (
                          <>
                            কোড নিশ্চিত করুন
                            <ArrowRight className="w-4 h-4" />
                          </>
                        )}
                      </button>
                    </form>
                  )}

                  {/* Step 3: PIN Confirmation */}
                  {step === 3 && (
                    <form onSubmit={handleConfirmPin} className="space-y-4 animate-in fade-in">
                      <div className="text-center pb-1">
                        <span className="text-xs text-slate-600 block">
                          পেমেন্ট সম্পন্ন করতে আপনার <strong>{brandName}</strong> গোপন পিন (PIN) দিন:
                        </span>
                      </div>

                      <div>
                        <div className="relative">
                          <input 
                            type="password" 
                            value={pin}
                            onChange={(e) => setPin(e.target.value)}
                            placeholder="•••••"
                            maxLength={5}
                            className="w-full text-center tracking-[0.5em] text-xl font-mono py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500"
                            required
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => setPin('12345')}
                            className="absolute right-2 top-2 px-2 py-1 text-[10px] bg-emerald-100 text-emerald-800 rounded font-semibold"
                          >
                            টেস্ট পিন (12345)
                          </button>
                        </div>
                      </div>

                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start gap-2">
                        <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <span>এটি সরাসরি অফিসিয়াল সিকিউর এন্ডপয়েন্টে এনক্রিপ্টেড হয়ে যাবে। জনতা মার্ট কোনো পিন সংরক্ষণ করে না।</span>
                      </div>

                      <button
                        type="submit"
                        disabled={isProcessing}
                        className="w-full py-3 rounded-xl text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                        style={{ backgroundColor: brandColor }}
                      >
                        {isProcessing ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            পেমেন্ট ভেরিফাই হচ্ছে...
                          </>
                        ) : (
                          <>
                            <Lock className="w-4 h-4" />
                            ৳{toBengaliNumber(amount)} পেমেন্ট নিশ্চিত করুন
                          </>
                        )}
                      </button>
                    </form>
                  )}
                </>
              )}
            </div>
          )}

          {/* Secure footer */}
          <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-center gap-2 text-[11px] text-slate-400">
            <Lock className="w-3 h-3" />
            <span>নিরাপদ ও সুরক্ষিত লেনদেনের পূর্ণ নিশ্চয়তা</span>
          </div>
        </div>

      </div>
    </div>
  );
};
