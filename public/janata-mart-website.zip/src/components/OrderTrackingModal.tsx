import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  Package, 
  CheckCircle2, 
  Clock, 
  Truck, 
  XCircle, 
  Calendar,
  AlertCircle,
  Phone,
  Hash
} from 'lucide-react';
import { Order, OrderStatus } from '../types';
import { toBengaliNumber } from '../data/bangladeshData';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  defaultOrderId?: string;
  onCancelOrder: (orderId: string) => void;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  orders,
  defaultOrderId,
  onCancelOrder
}) => {
  const [searchId, setSearchId] = useState(defaultOrderId || '');
  const [searchPhone, setSearchPhone] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(
    defaultOrderId ? (orders.find(o => o.orderId === defaultOrderId) || null) : (orders[0] || null)
  );

  useEffect(() => {
    if (defaultOrderId) {
      setSearchId(defaultOrderId);
      const matched = orders.find(o => o.orderId === defaultOrderId);
      if (matched) {
        setSelectedOrder(matched);
        setSearchPhone(matched.phone || '');
      }
    } else if (orders.length > 0 && !selectedOrder) {
      setSelectedOrder(orders[0]);
    }
  }, [defaultOrderId, orders, isOpen]);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const cleanId = searchId.trim().toUpperCase();
    const cleanPhone = searchPhone.trim().replace(/\D/g, '');

    if (!cleanId && !cleanPhone) {
      setErrorMsg('দয়া করে ট্র্যাকিং নম্বর এবং মোবাইল নম্বর লিখুন।');
      return;
    }

    const match = orders.find(o => {
      const oId = o.orderId.toUpperCase();
      const oPhone = o.phone.replace(/\D/g, '');

      if (cleanId && cleanPhone) {
        return (oId === cleanId || oId.includes(cleanId)) && (oPhone.endsWith(cleanPhone) || cleanPhone.endsWith(oPhone));
      } else if (cleanId) {
        return oId === cleanId || oId.includes(cleanId);
      } else {
        return oPhone.endsWith(cleanPhone) || cleanPhone.endsWith(oPhone);
      }
    });

    if (match) {
      setSelectedOrder(match);
      setErrorMsg('');
    } else {
      setSelectedOrder(null);
      setErrorMsg('প্রদত্ত ট্র্যাকিং নম্বর ও মোবাইল নম্বরের সাথে কোনো অর্ডার পাওয়া যায়নি। সঠিক তথ্য দিন।');
    }
  };

  const statusSteps: { label: string; key: OrderStatus }[] = [
    { label: 'অর্ডার গৃহিত', key: 'পেন্ডিং' },
    { label: 'প্রসেসিং', key: 'প্রসেসিং' },
    { label: 'শিপড (কুরিয়ারে)', key: 'শিপড' },
    { label: 'ডেলিভার্ড', key: 'ডেলিভার্ড' }
  ];

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'পেন্ডিং': return 0;
      case 'প্রসেসিং': return 1;
      case 'শিপড': return 2;
      case 'ডেলিভার্ড': return 3;
      case 'বাতিল': return -1;
      default: return 0;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-8 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">অর্ডার ট্র্যাকিং ও হিস্ট্রি</h2>
              <span className="text-xs text-slate-500">আপনার অর্ডারের লাইভ অগ্রগতি জানুন</span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Search Order bar with Tracking Number & Phone Number */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 shadow-sm">
            <h3 className="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-rose-600" />
              অর্ডার তথ্য যাচাই করে ট্র্যাক করুন:
            </h3>

            <form onSubmit={handleSearch} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    অর্ডার / ট্র্যাকিং নম্বর *
                  </label>
                  <div className="relative">
                    <Hash className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={searchId}
                      onChange={(e) => setSearchId(e.target.value)}
                      placeholder="যেমন: JM-123456"
                      className="w-full pl-9 pr-3 py-2 bg-white rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      value={searchPhone}
                      onChange={(e) => setSearchPhone(e.target.value)}
                      placeholder="যেমন: 017XXXXXXXX"
                      className="w-full pl-9 pr-3 py-2 bg-white rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer flex items-center justify-center gap-1.5 active:scale-[0.99]"
              >
                <Search className="w-3.5 h-3.5" />
                অর্ডার ট্র্যাক করুন
              </button>
            </form>

            {errorMsg && (
              <div className="mt-3 p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}
          </div>

          {/* If there are no orders at all */}
          {orders.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-14 h-14 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                <Package className="w-7 h-7" />
              </div>
              <p className="text-xs text-slate-500">আপনার কোনো সক্রিয় অর্ডার নেই!</p>
            </div>
          ) : (
            <>
              {/* Selected Order Detailed View */}
              {selectedOrder ? (
                <div className="p-5 rounded-2xl border border-slate-200 bg-white shadow-sm space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-sm text-slate-900">{selectedOrder.orderId}</span>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                          selectedOrder.status === 'ডেলিভার্ড' ? 'bg-emerald-100 text-emerald-800' :
                          selectedOrder.status === 'বাতিল' ? 'bg-red-100 text-red-700' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {selectedOrder.status}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        তারিখ: {selectedOrder.date} | পেমেন্ট: {selectedOrder.paymentDetails.method}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-black text-rose-600 block">
                        ৳{toBengaliNumber(selectedOrder.total)}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {toBengaliNumber(selectedOrder.items.length)}টি আইটেম
                      </span>
                    </div>
                  </div>

                  {/* Status Timeline Progress Bar */}
                  {selectedOrder.status === 'বাতিল' ? (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
                      <XCircle className="w-4 h-4 shrink-0" />
                      <span>এই অর্ডারটি বাতিল করা হয়েছে। কোনো প্রশ্ন থাকলে কাস্টমার কেয়ারে যোগাযোগ করুন।</span>
                    </div>
                  ) : (
                    <div>
                      <div className="text-xs font-semibold text-slate-700 mb-3 flex items-center justify-between">
                        <span>ডেলিভারি ট্র্যাকিং ধাপ:</span>
                        <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-1">
                          <Truck className="w-3.5 h-3.5" /> আনুমানিক ডেলিভারি: {selectedOrder.deliveryEstimatedDate}
                        </span>
                      </div>

                      <div className="grid grid-cols-4 gap-2 relative">
                        {statusSteps.map((step, idx) => {
                          const currentStepIdx = getStepIndex(selectedOrder.status);
                          const isDone = idx <= currentStepIdx;
                          const isCurrent = idx === currentStepIdx;

                          return (
                            <div key={step.key} className="flex flex-col items-center text-center">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs mb-1.5 transition-colors ${
                                isDone 
                                  ? 'bg-emerald-600 text-white shadow-md' 
                                  : 'bg-slate-100 text-slate-400'
                              } ${isCurrent ? 'ring-4 ring-emerald-100 animate-pulse' : ''}`}>
                                {isDone ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                              </div>
                              <span className={`text-[10px] font-semibold leading-tight ${
                                isDone ? 'text-slate-800' : 'text-slate-400'
                              }`}>
                                {step.label}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Order items preview */}
                  <div className="divide-y divide-slate-100 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                    <span className="font-semibold text-slate-700 block mb-2">অর্ডারের পণ্যসমূহ:</span>
                    {selectedOrder.items.map((it, i) => (
                      <div key={i} className="py-1.5 flex justify-between items-center">
                        <span className="text-slate-700 font-medium truncate max-w-[240px]">
                          {it.name} <span className="text-slate-400">× {toBengaliNumber(it.qty)}</span>
                        </span>
                        <span className="font-bold text-slate-900">৳{toBengaliNumber(it.price * it.qty)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Address info */}
                  <div className="text-xs text-slate-600 flex justify-between items-center bg-slate-50 p-3 rounded-xl">
                    <div>
                      <span className="font-semibold text-slate-800 block">{selectedOrder.name} ({selectedOrder.phone})</span>
                      <span className="text-[11px] text-slate-500">{selectedOrder.location} - {selectedOrder.address}</span>
                    </div>

                    {selectedOrder.status === 'পেন্ডিং' && (
                      <button
                        onClick={() => {
                          if (confirm('আপনি কি নিশ্চিত এই অর্ডারটি বাতিল করতে চান?')) {
                            onCancelOrder(selectedOrder.orderId);
                          }
                        }}
                        className="px-3 py-1 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                      >
                        অর্ডার বাতিল করুন
                      </button>
                    )}
                  </div>
                </div>
              ) : null}

              {/* Order history list */}
              <div>
                <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">সকল পূর্ববর্তী অর্ডারসমূহ</h3>
                <div className="space-y-2">
                  {orders.map((ord) => (
                    <div 
                      key={ord.orderId}
                      onClick={() => setSelectedOrder(ord)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        selectedOrder?.orderId === ord.orderId 
                          ? 'border-rose-500 bg-rose-50/40 ring-1 ring-rose-500/20' 
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-xs text-slate-900">{ord.orderId}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold">{ord.status}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{ord.date} • {ord.items.length}টি পণ্য</span>
                      </div>
                      <div className="font-bold text-xs text-rose-600">
                        ৳{toBengaliNumber(ord.total)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

        </div>

      </div>
    </div>
  );
};
