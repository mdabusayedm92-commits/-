import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  ShoppingCart, 
  Heart, 
  Truck, 
  ShieldCheck, 
  RotateCcw, 
  Star, 
  Share2, 
  Check, 
  PackageCheck,
  CheckCircle2,
  PhoneCall
} from 'lucide-react';
import { Product, Review } from '../types';
import { toBengaliNumber, playSound } from '../data/bangladeshData';

interface ProductDetailViewProps {
  product: Product;
  allProducts: Product[];
  isWished: boolean;
  onBack: () => void;
  onToggleWishlist: (id: number) => void;
  onAddToCart: (product: Product, qty: number, variant?: { color?: string; size?: string }) => void;
  onBuyNow: (product: Product, qty: number, variant?: { color?: string; size?: string }) => void;
  onAddReview: (productId: number, review: Omit<Review, 'id' | 'date'>) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({
  product,
  allProducts,
  isWished,
  onBack,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
  onAddReview,
  onSelectProduct
}) => {
  const [qty, setQty] = useState(1);
  const [selectedImg, setSelectedImg] = useState<string>(product.img);
  const [selectedColor, setSelectedColor] = useState<string>(product.variants?.colors?.[0] || '');
  const [selectedSize, setSelectedSize] = useState<string>(product.variants?.sizes?.[0] || '');
  
  const [reviewAuthor, setReviewAuthor] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    setSelectedImg(product.img);
    setSelectedColor(product.variants?.colors?.[0] || '');
    setSelectedSize(product.variants?.sizes?.[0] || '');
    setQty(1);
  }, [product]);

  const discountPercent = product.oldPrice 
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) 
    : 0;

  const handleQtyChange = (delta: number) => {
    setQty(prev => Math.max(1, Math.min(product.stock, prev + delta)));
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewComment.trim()) return;

    onAddReview(product.id, {
      author: reviewAuthor.trim() || 'সম্মানিত ক্রেতা',
      rating: reviewRating,
      comment: reviewComment.trim(),
      verified: true
    });

    setReviewComment('');
    setReviewSubmitted(true);
    playSound('success');
    setTimeout(() => setReviewSubmitted(false), 4000);
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Image list for gallery
  const allImages = Array.from(new Set([product.img, ...(product.additionalImages || [])]));

  // Related items
  const relatedProducts = allProducts
    .filter(p => p.id !== product.id && p.category === product.category)
    .slice(0, 4);

  return (
    <div className="container mx-auto px-4 py-6 max-w-5xl animate-in fade-in duration-300">
      
      {/* Back button & Breadcrumbs */}
      <div className="flex items-center justify-between gap-4 mb-6 text-xs sm:text-sm text-slate-500">
        <button 
          onClick={onBack}
          className="flex items-center gap-1.5 text-slate-700 hover:text-rose-600 font-bold bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm cursor-pointer transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> স্টোরে ফিরুন
        </button>

        <div className="hidden sm:flex items-center gap-1.5 truncate">
          <span className="hover:text-rose-600 cursor-pointer" onClick={onBack}>হোম</span>
          <span>&gt;</span>
          <span className="text-rose-600 font-semibold">{product.category}</span>
          <span>&gt;</span>
          <span className="text-slate-800 font-medium truncate max-w-[200px]">{product.name}</span>
        </div>

        <button 
          onClick={handleShare}
          className="flex items-center gap-1.5 text-slate-600 hover:text-rose-600 bg-white px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-semibold cursor-pointer shadow-sm transition-colors"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>{copiedLink ? 'লিংক কপি হয়েছে!' : 'শেয়ার করুন'}</span>
        </button>
      </div>

      {/* Main PDP Grid */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-8 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
        
        {/* Left: Product Media Gallery with Multiple Thumbnails */}
        <div className="space-y-4">
          <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 shadow-inner">
            <img 
              src={selectedImg} 
              alt={product.name}
              className="w-full h-full object-cover transition-all duration-300"
            />
            {discountPercent > 0 && (
              <span className="absolute top-4 left-4 bg-rose-600 text-white text-xs font-black px-3 py-1 rounded-full shadow-md">
                {toBengaliNumber(discountPercent)}% মূল্যছাড়
              </span>
            )}
            <button
              onClick={() => onToggleWishlist(product.id)}
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm text-slate-700 hover:text-rose-600 shadow-md flex items-center justify-center cursor-pointer transition-transform hover:scale-110"
              title={isWished ? 'পছন্দ তালিকা থেকে সরান' : 'পছন্দ তালিকায় রাখুন'}
            >
              <Heart className={`w-5 h-5 ${isWished ? 'fill-rose-600 text-rose-600' : ''}`} />
            </button>
          </div>

          {/* Additional Image Thumbnails if available */}
          {allImages.length > 1 && (
            <div className="flex gap-2.5 overflow-x-auto pb-1">
              {allImages.map((imgUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImg(imgUrl)}
                  className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                    selectedImg === imgUrl ? 'border-rose-600 ring-2 ring-rose-500/20' : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <img src={imgUrl} alt={`${product.name} angle ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Quick Features Row */}
          <div className="grid grid-cols-3 gap-2 text-center text-[11px] font-semibold text-slate-600 pt-1">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <Truck className="w-4 h-4 mx-auto text-rose-600 mb-1" />
              ২৪-৪৮ ঘণ্টায় ডেলিভারি
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <ShieldCheck className="w-4 h-4 mx-auto text-rose-600 mb-1" />
              ১০০% আসল পণ্য
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <RotateCcw className="w-4 h-4 mx-auto text-rose-600 mb-1" />
              ৭ দিনের রিটার্ন সুবিধা
            </div>
          </div>
        </div>

        {/* Right: Product Details & Purchase Controls */}
        <div className="flex flex-col">
          <div className="mb-3">
            <span className="inline-block px-3 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-600 mb-2">
              {product.category}
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug mb-1">
              {product.name}
            </h1>
            {product.nameEn && (
              <p className="text-xs text-slate-400 font-medium">{product.nameEn}</p>
            )}
            <div className="text-xs text-slate-500 font-semibold mt-1">
              পরিমাণ/ইউনিট: <span className="text-slate-800">{product.unit}</span>
            </div>
          </div>

          {/* Rating & Stock Status */}
          <div className="flex flex-wrap items-center gap-3 pb-3 border-b border-slate-100 text-xs">
            <div className="flex items-center gap-1 bg-amber-50 px-2.5 py-1 rounded-lg text-amber-700 font-bold">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>{product.rating}</span>
              <span className="text-slate-400 font-normal">({toBengaliNumber(product.reviewsCount || product.reviews.length)} রিভিউ)</span>
            </div>

            <div className="flex items-center gap-1.5 text-emerald-700 font-semibold bg-emerald-50 px-3 py-1 rounded-lg">
              <PackageCheck className="w-4 h-4" />
              <span>স্টকে আছে ({toBengaliNumber(product.stock)} পিস)</span>
            </div>

            {product.warranty && (
              <span className="text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg font-semibold">
                🛡️ {product.warranty}
              </span>
            )}
          </div>

          {/* Pricing Row */}
          <div className="py-3.5 flex items-baseline gap-3">
            <span className="text-3xl font-black text-rose-600">
              ৳{toBengaliNumber(product.price)}
            </span>
            {product.oldPrice && (
              <span className="text-base text-slate-400 line-through">
                ৳{toBengaliNumber(product.oldPrice)}
              </span>
            )}
            {discountPercent > 0 && (
              <span className="text-xs font-bold text-emerald-600 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                বাঁচাচ্ছেন ৳{toBengaliNumber(product.oldPrice! - product.price)}
              </span>
            )}
          </div>

          {/* Color Variants if available */}
          {product.variants?.colors && product.variants.colors.length > 0 && (
            <div className="py-2.5 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700 block mb-2">
                কালার নির্বাচন করুন: <span className="text-rose-600 font-semibold">{selectedColor}</span>
              </span>
              <div className="flex flex-wrap gap-2">
                {product.variants.colors.map(col => (
                  <button
                    key={col}
                    type="button"
                    onClick={() => setSelectedColor(col)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedColor === col 
                        ? 'bg-rose-600 text-white shadow-sm ring-2 ring-rose-500/20' 
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                    }`}
                  >
                    {col}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Size Variants if available */}
          {product.variants?.sizes && product.variants.sizes.length > 0 && (
            <div className="py-2.5 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700 block mb-2">
                সাইজ নির্বাচন করুন: <span className="text-rose-600 font-semibold">{selectedSize}</span>
              </span>
              <div className="flex flex-wrap gap-2">
                {product.variants.sizes.map(sz => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setSelectedSize(sz)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedSize === sz 
                        ? 'bg-rose-600 text-white shadow-sm ring-2 ring-rose-500/20' 
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity Selector */}
          <div className="py-3 flex items-center gap-4 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-700">পরিমাণ:</span>
            <div className="flex items-center border border-slate-300 rounded-xl bg-slate-50 overflow-hidden shadow-inner">
              <button 
                onClick={() => handleQtyChange(-1)}
                className="w-9 h-9 flex items-center justify-center font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                -
              </button>
              <span className="w-10 text-center font-bold text-slate-800 text-sm">
                {toBengaliNumber(qty)}
              </span>
              <button 
                onClick={() => handleQtyChange(1)}
                className="w-9 h-9 flex items-center justify-center font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                +
              </button>
            </div>
            <span className="text-xs text-slate-400">
              মোট: <strong className="text-slate-800">৳{toBengaliNumber(product.price * qty)}</strong>
            </span>
          </div>

          {/* Action Buttons: Add to Cart & Buy Now */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 py-3 mt-1">
            <button
              onClick={() => {
                playSound('pop');
                onAddToCart(product, qty, { color: selectedColor, size: selectedSize });
              }}
              className="py-3 px-4 rounded-xl border-2 border-rose-600 text-rose-600 hover:bg-rose-50 font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-98"
            >
              <ShoppingCart className="w-4 h-4" />
              কার্টে যোগ করুন
            </button>

            <button
              onClick={() => {
                playSound('pop');
                onBuyNow(product, qty, { color: selectedColor, size: selectedSize });
              }}
              className="py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-600/30 transition-all cursor-pointer active:scale-98"
            >
              এখনই কিনুন
            </button>
          </div>

          {/* Delivery & Customer Support Box */}
          <div className="mt-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs text-slate-700">
            <div className="flex items-center gap-2.5">
              <Truck className="w-4 h-4 text-rose-600 shrink-0" />
              <span><strong>ডেলিভারি চার্জ:</strong> ঢাকা সিটিতে ৳৭০ • ঢাকার বাইরে ৳১৩০</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>ক্যাশ অন ডেলিভারি:</strong> পণ্য হাতে পেয়ে চেক করে টাকা পরিশোধ করুন।</span>
            </div>
            <div className="flex items-center gap-2.5 pt-1 border-t border-slate-200/60">
              <PhoneCall className="w-4 h-4 text-blue-600 shrink-0" />
              <span>অর্ডারে কোনো সমস্যা হলে সরাসরি কল করুন: <a href="tel:09612345678" className="font-bold text-rose-600 hover:underline">০৯৬১২-৩৪৫৬৭৮</a></span>
            </div>
          </div>

        </div>
      </div>

      {/* Product Description Tab */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm mb-10">
        <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3 mb-4">
          পণ্যের বিস্তারিত বিবরণ ও গুণাগুণ
        </h2>
        <div className="prose prose-slate max-w-none text-slate-700 leading-relaxed text-sm whitespace-pre-line">
          {product.desc}
        </div>
      </div>

      {/* Reviews & Ratings Section */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm mb-10">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">গ্রাহকদের রিভিউ ও রেটিং</h2>
            <div className="flex items-center gap-2 mt-1">
              <div className="flex text-amber-400">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star 
                    key={s} 
                    className={`w-4 h-4 ${s <= Math.round(product.rating) ? 'fill-amber-400' : 'text-slate-200'}`} 
                  />
                ))}
              </div>
              <span className="text-xs font-bold text-slate-700">{product.rating} / ৫.০</span>
              <span className="text-xs text-slate-400">({toBengaliNumber(product.reviews.length)}টি রিভিউ)</span>
            </div>
          </div>
        </div>

        {/* Add Review Form */}
        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 mb-8">
          <h3 className="text-sm font-bold text-slate-800 mb-3">আপনার মতামত দিন</h3>
          
          {reviewSubmitted ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              আপনার মূল্যবান রিভিউটি সফলভাবে গৃহীত হয়েছে! ধন্যবাদ।
            </div>
          ) : (
            <form onSubmit={handleReviewSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">আপনার নাম</label>
                  <input
                    type="text"
                    value={reviewAuthor}
                    onChange={(e) => setReviewAuthor(e.target.value)}
                    placeholder="আপনার পুরো নাম লিখুন"
                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">রেটিং নির্বাচন করুন</label>
                  <div className="flex items-center gap-1.5 py-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setReviewRating(star)}
                        className="p-1 cursor-pointer focus:outline-none transition-transform hover:scale-125"
                      >
                        <Star 
                          className={`w-5 h-5 ${star <= reviewRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`} 
                        />
                      </button>
                    ))}
                    <span className="text-xs font-bold text-slate-600 ml-2">({toBengaliNumber(reviewRating)} স্টার)</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">আপনার রিভিউ বা মন্তব্য *</label>
                <textarea
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="পণ্যটির গুণগত মান, ডেলিভারি ও ব্যবহার কেমন লেগেছে লিখুন..."
                  rows={3}
                  className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
              >
                রিভিউ জমা দিন
              </button>
            </form>
          )}
        </div>

        {/* Existing Reviews List */}
        <div className="space-y-4">
          {product.reviews.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-6">
              এই পণ্যে এখনো কোনো রিভিউ নেই। প্রথম রিভিউটি আপনিই দিন!
            </p>
          ) : (
            product.reviews.map((rev) => (
              <div key={rev.id} className="p-4 rounded-xl border border-slate-100 bg-white">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-800">{rev.author}</span>
                    {rev.verified && (
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                        <Check className="w-3 h-3" /> ভেরিফাইড ক্রেতা
                      </span>
                    )}
                  </div>
                  <div className="flex text-amber-400">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className={`w-3 h-3 ${s <= rev.rating ? 'fill-amber-400' : 'text-slate-200'}`} />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{rev.comment}</p>
                <span className="text-[10px] text-slate-400 block mt-2">{rev.date}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Related Products Carousel/Grid */}
      {relatedProducts.length > 0 && (
        <div className="mb-10">
          <h2 className="text-lg font-bold text-slate-900 mb-4">একই ক্যাটাগরির অন্যান্য পণ্য</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {relatedProducts.map(rel => (
              <div 
                key={rel.id}
                onClick={() => onSelectProduct(rel)}
                className="bg-white rounded-2xl border border-slate-200 p-3 hover:shadow-lg transition-all cursor-pointer group"
              >
                <div className="aspect-square rounded-xl overflow-hidden bg-slate-50 mb-2">
                  <img src={rel.img} alt={rel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <h4 className="text-xs font-bold text-slate-800 truncate mb-1">{rel.name}</h4>
                <div className="text-xs font-black text-rose-600">৳{toBengaliNumber(rel.price)}</div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
