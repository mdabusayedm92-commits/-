import { useEffect } from 'react';
import { Product } from '../types';

interface SeoHeadProps {
  product?: Product | null;
  category?: string;
}

export const SeoHead: React.FC<SeoHeadProps> = ({ product, category }) => {
  useEffect(() => {
    let title = 'জনতা মার্ট - Janata Mart | বাংলাদেশের বিশ্বস্ত অনলাইন শপিং প্ল্যাটফর্ম';
    let description = 'জনতা মার্ট - গ্যাজেট, ফ্যাশন, বিউটি ও কিচেনের সেরা পণ্য সেরা দামে কিনুন। ক্যাশ অন ডেলিভারি ও বিকাশ/নগদ পেমেন্ট।';

    if (product) {
      title = `${product.name} (৳${product.price}) | জনতা মার্ট`;
      description = `${product.name} কিনুন সেরা মূল্যে। ${product.desc.slice(0, 140)}... ক্যাশ অন ডেলিভারি সুবিধা।`;
    } else if (category && category !== 'all') {
      title = `${category} কালেকশন | জনতা মার্ট অনলাইন শপিং`;
      description = `সেরা ${category} পণ্য সামগ্রী কিনুন আকর্ষণীয় মূল্যছাড় ও দ্রুত ডেলিভারিতে।`;
    }

    document.title = title;

    // Update meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', description);
    }

    // Dynamic Product Schema.org JSON-LD
    let scriptTag = document.getElementById('dynamic-seo-ld');
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = 'dynamic-seo-ld';
      scriptTag.setAttribute('type', 'application/ld+json');
      document.head.appendChild(scriptTag);
    }

    if (product) {
      const productSchema = {
        '@context': 'https://schema.org/',
        '@type': 'Product',
        name: product.name,
        image: [product.img],
        description: product.desc,
        sku: `JM-${product.id}`,
        brand: {
          '@type': 'Brand',
          name: 'জনতা মার্ট'
        },
        offers: {
          '@type': 'Offer',
          url: window.location.href,
          priceCurrency: 'BDT',
          price: product.price,
          availability: product.stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
          itemCondition: 'https://schema.org/NewCondition'
        },
        aggregateRating: {
          '@type': 'AggregateRating',
          ratingValue: product.rating || 4.8,
          reviewCount: Math.max(1, product.reviewsCount || product.reviews.length || 5)
        }
      };
      scriptTag.textContent = JSON.stringify(productSchema);
    } else {
      scriptTag.textContent = '';
    }
  }, [product, category]);

  return null;
};
