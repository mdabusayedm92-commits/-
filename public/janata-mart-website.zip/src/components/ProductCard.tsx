import React from 'react';
import { Heart, ShoppingCart, Star, Check } from 'lucide-react';
import { Product } from '../types';
import { toBengaliNumber, playSound } from '../data/bangladeshData';

interface ProductCardProps {
  product: Product;
  isWished: boolean;
  onToggleWishlist: (productId: number) => void;
  onAddToCart: (product: Product) => void;
  onOpenDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWished,
  onToggleWishlist,
  onAddToCart,
  onOpenDetails
}) => {
  const discountPercent = product.oldPrice 
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) 
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('pop');
    onAddToCart(product);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('click');
    onToggleWishlist(product.id);
  };

  return (
    <div 
      onClick={() => onOpenDetails(product)}
      className="group bg-white rounded-2xl border border-slate-200 hover:border-rose-300 hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col cursor-pointer relative"
    >
      {/* Product Image Area */}
      <div className="relative aspect-square w-full bg-slate-50 overflow-hidden">
        <img 
          src={product.img} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Discount Badge */}
        {discountPercent > 0 && (
          <span className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[11px] font-black px-2 py-0.5 rounded-full shadow-sm">
            {toBengaliNumber(discountPercent)}% ছাড়
          </span>
        )}

        {/* Wishlist Button */}
        <button
          onClick={handleToggleWishlist}
          className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
            isWished 
              ? 'bg-rose-50 text-rose-600 shadow-sm' 
              : 'bg-white/80 backdrop-blur-sm text-slate-500 hover:text-rose-600 hover:bg-white'
          }`}
          title={isWished ? 'পছন্দের তালিকা থেকে সরান' : 'পছন্দের তালিকায় রাখুন'}
        >
          <Heart className={`w-4 h-4 ${isWished ? 'fill-rose-600 text-rose-600' : ''}`} />
        </button>

        {/* Stock Alert overlay if low */}
        {product.stock <= 5 && (
          <div className="absolute bottom-2 left-2 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow">
            স্টক সীমিত ({toBengaliNumber(product.stock)}টি বাকি)
          </div>
        )}
      </div>

      {/* Card Content Area */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1">
        <div className="flex items-center justify-between text-[11px] mb-1">
          <span className="text-rose-600 font-semibold">{product.category}</span>
          <span className="text-slate-400 font-medium">{product.unit}</span>
        </div>

        {/* Product Title */}
        <h3 className="font-bold text-slate-800 text-sm leading-snug line-clamp-2 group-hover:text-rose-600 transition-colors mb-1.5 h-10">
          {product.name}
        </h3>

        {/* Rating & Review Count */}
        <div className="flex items-center gap-1.5 mb-2.5">
          <div className="flex items-center text-amber-500 text-xs">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="ml-1 font-bold text-slate-700">{product.rating}</span>
          </div>
          <span className="text-slate-400 text-[11px]">({toBengaliNumber(product.reviewsCount || product.reviews.length)})</span>
          <span className="text-emerald-600 text-[10px] font-semibold flex items-center gap-0.5 ml-auto">
            <Check className="w-3 h-3" /> ইন-স্টক
          </span>
        </div>

        {/* Pricing */}
        <div className="mt-auto pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <div className="text-base sm:text-lg font-black text-rose-600">
              ৳{toBengaliNumber(product.price)}
            </div>
            {product.oldPrice && (
              <div className="text-xs text-slate-400 line-through">
                ৳{toBengaliNumber(product.oldPrice)}
              </div>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white px-3 py-1.5 sm:py-2 rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>কার্টে নিন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
