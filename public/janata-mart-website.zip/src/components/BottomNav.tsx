import React from 'react';
import { Home, Grid, ShoppingBag, Heart, Package } from 'lucide-react';
import { toBengaliNumber } from '../data/bangladeshData';

interface BottomNavProps {
  activeTab: 'home' | 'categories' | 'cart' | 'wishlist' | 'orders';
  cartCount: number;
  wishlistCount: number;
  onGoHome: () => void;
  onScrollToCategories: () => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenOrders: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  cartCount,
  wishlistCount,
  onGoHome,
  onScrollToCategories,
  onOpenCart,
  onOpenWishlist,
  onOpenOrders
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 md:hidden py-1.5 px-3 shadow-lg">
      <div className="flex items-center justify-around">
        {/* Home */}
        <button
          onClick={onGoHome}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'home' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px]">হোম</span>
        </button>

        {/* Categories */}
        <button
          onClick={onScrollToCategories}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'categories' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px]">ক্যাটাগরি</span>
        </button>

        {/* Cart */}
        <button
          onClick={onOpenCart}
          className="relative flex flex-col items-center gap-0.5 p-1 text-rose-600 font-bold cursor-pointer"
        >
          <div className="relative">
            <div className="w-9 h-9 -mt-3.5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-600/30">
              <ShoppingBag className="w-4 h-4" />
            </div>
            {cartCount > 0 && (
              <span className="absolute -top-4 -right-1 bg-amber-400 text-slate-900 text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white">
                {toBengaliNumber(cartCount)}
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-800">কার্ট</span>
        </button>

        {/* Wishlist */}
        <button
          onClick={onOpenWishlist}
          className={`relative flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'wishlist' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Heart className="w-5 h-5" />
          {wishlistCount > 0 && (
            <span className="absolute top-0 right-1 w-3.5 h-3.5 rounded-full bg-rose-600 text-white text-[8px] font-bold flex items-center justify-center">
              {toBengaliNumber(wishlistCount)}
            </span>
          )}
          <span className="text-[10px]">উইশলিস্ট</span>
        </button>

        {/* Orders */}
        <button
          onClick={onOpenOrders}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'orders' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Package className="w-5 h-5" />
          <span className="text-[10px]">অর্ডার</span>
        </button>
      </div>
    </div>
  );
};
