import React, { useState, useEffect } from 'react';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  Tag, 
  Check, 
  CreditCard, 
  AlertCircle,
  Truck,
  Sparkles
} from 'lucide-react';
import { CartItem, UserProfile, PaymentMethod, Coupon } from '../types';
import { BD_LOCATIONS, AVAILABLE_COUPONS, toBengaliNumber, playSound } from '../data/bangladeshData';

interface CartCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  currentUser: UserProfile | null;
  onUpdateQty: (productId: number, delta: number, color?: string, size?: string) => void;
  onRemoveItem: (productId: number, color?: string, size?: string) => void;
  onClearCart: () => void;
  onProceedToPayment: (orderData: {
    name: string;
    phone: string;
    division: string;
    district: string;
    upazila: string;
    address: string;
    paymentMethod: PaymentMethod;
    subtotal: number;
    deliveryCharge: number;
    discount: number;
    couponCode?: string;
    total: number;
  }) => void;
}

export const CartCheckoutModal: React.FC<CartCheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  currentUser,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onProceedToPayment
}) => {
  // Form States
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [division, setDivision] = useState('ঢাকা');
  const [district, setDistrict] = useState('ঢাকা');
  const [upazila, setUpazila] = useState('মিরপুর');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('COD');
  
  // Coupon State
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  // Auto-fill from user profile
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setPhone(currentUser.phone || '');
      if (currentUser.division) setDivision(currentUser.division);
      if (currentUser.district) setDistrict(currentUser.district);
      if (currentUser.upazila) setUpazila(currentUser.upazila);
      if (currentUser.address) setAddress(currentUser.address);
    }
  }, [currentUser, isOpen]);

  if (!isOpen) return null;

  // Pricing Calculations
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  // Dynamic delivery charge calculation
  let baseDelivery = 130;
  if (district === 'ঢাকা' || district === 'ঢাকা সদর') {
    baseDelivery = 70;
  } else if (division === 'ঢাকা') {
    baseDelivery = 100;
  }

  // Calculate discount
  let discount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discountPercent) {
      discount = Math.round((subtotal * appliedCoupon.discountPercent) / 100);
    } else if (appliedCoupon.discountAmount) {
      discount = appliedCoupon.discountAmount;
    }
  }

  // Free shipping check if subtotal > 2000 or coupon is FREESHIP
  let finalDelivery = baseDelivery;
  if (appliedCoupon?.code === 'FREESHIP' || subtotal >= 2000) {
    finalDelivery = 0;
  }

  const grandTotal = Math.max(0, subtotal - discount + finalDelivery);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    const code = couponInput.trim().toUpperCase();
    const found = AVAILABLE_COUPONS.find(c => c.code === code);

    if (!found) {
      setCouponError('অবৈধ কুপন কোড! JANATA10, NEW50 বা FREESHIP ট্রাই করুন।');
      return;
    }

    if (subtotal < found.minSpend) {
      setCouponError(`এই কুপন ব্যবহারের জন্য সর্বনিম্ন ৳${toBengaliNumber(found.minSpend)} টাকার অর্ডার প্রয়োজন।`);
      return;
    }

    setAppliedCoupon(found);
    playSound('success');
  };

  const handleDivisionChange = (newDiv: string) => {
    setDivision(newDiv);
    const districts = BD_LOCATIONS[newDiv] ? Object.keys(BD_LOCATIONS[newDiv]) : [];
    if (districts.length > 0) {
      const firstDist = districts[0];
      setDistrict(firstDist);
      const upazilas = BD_LOCATIONS[newDiv][firstDist] || [];
      setUpazila(upazilas[0] || '');
    } else {
      setDistrict('');
      setUpazila('');
    }
  };

  const handleDistrictChange = (newDist: string) => {
    setDistrict(newDist);
    const upazilas = (BD_LOCATIONS[division] && BD_LOCATIONS[division][newDist]) || [];
    setUpazila(upazilas[0] || '');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !address.trim()) {
      alert('অনুগ্রহ করে নাম, মোবাইল নম্বর এবং বিস্তারিত ঠিকানা সঠিকভাবে লিখুন।');
      return;
    }

    onProceedToPayment({
      name: name.trim(),
      phone: phone.trim(),
      division,
      district,
      upazila,
      address: address.trim(),
      paymentMethod,
      subtotal,
      deliveryCharge: finalDelivery,
      discount,
      couponCode: appliedCoupon?.code,
      total: grandTotal
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl h-full bg-white flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">আপনার শপিং ব্যাগ</h2>
              <span className="text-xs text-slate-500">{toBengaliNumber(cart.length)}টি আইটেম নির্বাচিত</span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* Cart Empty View */}
          {cart.length === 0 ? (
            <div className="text-center py-16 space-y-4">
              <div className="w-20 h-20 mx-auto rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <ShoppingBag className="w-10 h-10" />
              </div>
              <h3 className="text-base font-bold text-slate-800">আপনার কার্ট বর্তমানে খালি!</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                আমাদের আকর্ষণীয় পণ্যের কালেকশন দেখুন এবং আপনার পছন্দের আইটেম কার্টে যোগ করুন।
              </p>
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
              >
                পণ্য দেখুন
              </button>
            </div>
          ) : (
            <>
              {/* Cart Items List */}
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-600 pb-1">
                  <span>নির্বাচিত পণ্যসমূহ</span>
                  <button 
                    onClick={() => {
                      playSound('trash');
                      onClearCart();
                    }}
                    className="text-rose-600 hover:underline flex items-center gap-1 text-[11px]"
                  >
                    <Trash2 className="w-3 h-3" /> সব মুছুন
                  </button>
                </div>

                <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-sm">
                  {cart.map((item) => (
                    <div key={item.id} className="p-3.5 flex items-center gap-3">
                      <img 
                        src={item.img} 
                        alt={item.name} 
                        className="w-16 h-16 rounded-xl object-cover bg-slate-100 border border-slate-100 shrink-0"
                      />
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-slate-800 truncate mb-0.5">{item.name}</h4>
                        <div className="text-[11px] text-slate-400">{item.unit}</div>
                        {(item.selectedColor || item.selectedSize) && (
                          <div className="flex flex-wrap items-center gap-1.5 mt-1">
                            {item.selectedColor && (
                              <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-medium border border-slate-200">
                                রঙ: {item.selectedColor}
                              </span>
                            )}
                            {item.selectedSize && (
                              <span className="text-[10px] bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded font-medium border border-rose-100">
                                সাইজ: {item.selectedSize}
                              </span>
                            )}
                          </div>
                        )}
                        <div className="text-xs font-black text-rose-600 mt-1">
                          ৳{toBengaliNumber(item.price * item.qty)}
                          <span className="text-[10px] text-slate-400 font-normal ml-1">
                            (৳{toBengaliNumber(item.price)} × {toBengaliNumber(item.qty)})
                          </span>
                        </div>
                      </div>

                      {/* Quantity Controller */}
                      <div className="flex items-center gap-2">
                        <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                          <button
                            onClick={() => {
                              playSound('pop');
                              onUpdateQty(item.id, -1, item.selectedColor, item.selectedSize);
                            }}
                            className="w-7 h-7 flex items-center justify-center font-bold text-slate-600 hover:bg-slate-200 cursor-pointer"
                          >
                            -
                          </button>
                          <span className="w-7 text-center font-bold text-xs text-slate-800">
                            {toBengaliNumber(item.qty)}
                          </span>
                          <button
                            onClick={() => {
                              playSound('pop');
                              onUpdateQty(item.id, 1, item.selectedColor, item.selectedSize);
                            }}
                            className="w-7 h-7 flex items-center justify-center font-bold text-slate-600 hover:bg-slate-200 cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => {
                            playSound('trash');
                            onRemoveItem(item.id, item.selectedColor, item.selectedSize);
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="পণ্যটি সরান"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Coupon Code Section */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="কুপন কোড (যেমন: JANATA10)"
                      className="w-full pl-9 pr-3 py-2 bg-white rounded-xl border border-slate-300 text-xs font-mono uppercase focus:outline-none focus:ring-2 focus:ring-rose-500"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    প্রয়োগ
                  </button>
                </form>

                {couponError && (
                  <div className="mt-2 text-[11px] text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{couponError}</span>
                  </div>
                )}

                {appliedCoupon && (
                  <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-[11px] text-emerald-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span><strong>{appliedCoupon.code}</strong> কার্যকর হয়েছে (-৳{toBengaliNumber(discount)})</span>
                    </div>
                    <button 
                      onClick={() => setAppliedCoupon(null)}
                      className="text-red-500 hover:underline font-semibold"
                    >
                      মুছুন
                    </button>
                  </div>
                )}

                {/* Available Coupons hints */}
                <div className="mt-2 flex flex-wrap gap-1.5 text-[10px]">
                  <span className="text-slate-400">উপলব্ধ অফার:</span>
                  <button 
                    type="button" 
                    onClick={() => { setCouponInput('JANATA10'); }}
                    className="bg-white border border-slate-300 px-1.5 py-0.5 rounded text-rose-600 font-bold"
                  >
                    JANATA10
                  </button>
                  <button 
                    type="button" 
                    onClick={() => { setCouponInput('FREESHIP'); }}
                    className="bg-white border border-slate-300 px-1.5 py-0.5 rounded text-rose-600 font-bold"
                  >
                    FREESHIP
                  </button>
                </div>
              </div>

              {/* Checkout Delivery & Customer Form */}
              <form id="checkoutForm" onSubmit={handleSubmit} className="space-y-4 pt-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-rose-600" /> ডেলিভারি তথ্য
                  </h3>
                  {currentUser && (
                    <span className="text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> প্রোফাইল থেকে পূরণ
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">গ্রাহকের পূর্ণ নাম *</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="আপনার নাম লিখুন"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">সচল মোবাইল নম্বর *</label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="01XXXXXXXXX"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono"
                      required
                    />
                  </div>
                </div>

                {/* Division & District */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">বিভাগ *</label>
                    <select
                      value={division}
                      onChange={(e) => handleDivisionChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                    >
                      {Object.keys(BD_LOCATIONS).map((div) => (
                        <option key={div} value={div}>{div}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">জেলা *</label>
                    <select
                      value={district}
                      onChange={(e) => handleDistrictChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                    >
                      {division && BD_LOCATIONS[division] && Object.keys(BD_LOCATIONS[division]).map((dist) => (
                        <option key={dist} value={dist}>{dist}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Upazila / Area */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">থানা / উপজেলা *</label>
                  <select
                    value={upazila}
                    onChange={(e) => setUpazila(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  >
                    {division && district && BD_LOCATIONS[division] && BD_LOCATIONS[division][district] && 
                      BD_LOCATIONS[division][district].map((u) => (
                        <option key={u} value={u}>{u}</option>
                      ))
                    }
                  </select>
                </div>

                {/* Street address */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">বিস্তারিত ঠিকানা (বাসা নম্বর, রোড, এলাকা) *</label>
                  <textarea
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="যেমন: বাড়ি ১২, রোড ৪, সেক্টর ৭, উত্তরা"
                    rows={2}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
                    required
                  />
                </div>

                {/* Payment Method Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-2">পেমেন্ট পদ্ধতি নির্বাচন করুন *</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    
                    {/* COD */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('COD')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                        paymentMethod === 'COD'
                          ? 'border-rose-600 bg-rose-50/70 text-rose-700 ring-2 ring-rose-500/20'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <Truck className="w-5 h-5 text-rose-600" />
                      <span className="text-xs font-bold leading-tight">ক্যাশ অন ডেলিভারি</span>
                    </button>

                    {/* bKash */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bKash')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                        paymentMethod === 'bKash'
                          ? 'border-[#E2136E] bg-pink-50 text-[#E2136E] ring-2 ring-pink-500/20'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="w-5 h-5 rounded-full bg-[#E2136E] text-white flex items-center justify-center font-bold text-xs">b</div>
                      <span className="text-xs font-bold leading-tight">বিকাশ (bKash)</span>
                    </button>

                    {/* Nagad */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('Nagad')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                        paymentMethod === 'Nagad'
                          ? 'border-[#F7941D] bg-orange-50 text-[#F7941D] ring-2 ring-orange-500/20'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="w-5 h-5 rounded-full bg-[#F7941D] text-white flex items-center justify-center font-bold text-xs">ন</div>
                      <span className="text-xs font-bold leading-tight">নগদ (Nagad)</span>
                    </button>

                    {/* Card */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('Card')}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                        paymentMethod === 'Card'
                          ? 'border-blue-600 bg-blue-50 text-blue-700 ring-2 ring-blue-500/20'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <CreditCard className="w-5 h-5 text-blue-600" />
                      <span className="text-xs font-bold leading-tight">কার্ড / নেটব্যাংকিং</span>
                    </button>

                  </div>
                </div>

                {/* Price Breakdown Bill Card */}
                <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-100 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>পণ্যের মূল্য (সাবটোটাল):</span>
                    <span className="font-bold">৳{toBengaliNumber(subtotal)}</span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span>ডেলিভারি চার্জ ({(district === 'ঢাকা' || district === 'ঢাকা সদর') ? 'ঢাকা সিটি' : 'ঢাকার বাইরে'}):</span>
                    {finalDelivery === 0 ? (
                      <span className="font-bold text-emerald-600">ফ্রি ডেলিভারি!</span>
                    ) : (
                      <span className="font-bold">৳{toBengaliNumber(finalDelivery)}</span>
                    )}
                  </div>

                  {discount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold">
                      <span>কুপন মূল্যছাড়:</span>
                      <span>-৳{toBengaliNumber(discount)}</span>
                    </div>
                  )}

                  <div className="border-t border-rose-200/80 pt-2 flex justify-between items-baseline font-black text-sm sm:text-base text-rose-600">
                    <span>সর্বমোট প্রদেয় বিল:</span>
                    <span>৳{toBengaliNumber(grandTotal)}</span>
                  </div>
                </div>

              </form>
            </>
          )}

        </div>

        {/* Sticky Action Footer */}
        {cart.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-slate-200 bg-white shadow-lg">
            <button
              type="submit"
              form="checkoutForm"
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-black text-sm sm:text-base shadow-xl shadow-rose-600/30 flex items-center justify-between cursor-pointer transition-all active:scale-[0.99]"
            >
              <span>
                {paymentMethod === 'COD' 
                  ? 'অর্ডার নিশ্চিত করুন (ক্যাশ অন ডেলিভারি)' 
                  : `${paymentMethod === 'bKash' ? 'বিকাশ' : paymentMethod === 'Nagad' ? 'নগদ' : 'কার্ড'} গেটওয়ে দিয়ে পে করুন`}
              </span>
              <div className="flex items-center gap-2">
                <span className="bg-white/20 px-2 py-0.5 rounded-lg text-xs font-mono">
                  ৳{toBengaliNumber(grandTotal)}
                </span>
                <ArrowRight className="w-5 h-5" />
              </div>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
