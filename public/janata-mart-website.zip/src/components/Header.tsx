import React, { useState, useMemo } from 'react';
import { 
  Search, 
  User, 
  X,
  PhoneCall,
  Sparkles,
  TrendingUp,
  Truck
} from 'lucide-react';
import { UserProfile, Product } from '../types';
import { toBengaliNumber } from '../data/bangladeshData';

interface HeaderProps {
  currentUser: UserProfile | null;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenProfile: () => void;
  onSelectCategory: (category: string) => void;
  selectedCategory: string;
  products?: Product[];
  onSelectProduct?: (product: Product) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  searchQuery,
  onSearchChange,
  onOpenProfile,
  onSelectCategory,
  selectedCategory,
  products = [],
  onSelectProduct
}) => {
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const categories = [
    { id: 'all', label: 'সব পণ্য' },
    { id: 'ইলেকট্রনিক্স', label: 'ইলেকট্রনিক্স' },
    { id: 'ফ্যাশন', label: 'ফ্যাশন ও পোশাক' },
    { id: 'কিচেন', label: 'হোম ও কিচেন' },
    { id: 'বিউটি', label: 'বিউটি ও কেয়ার' }
  ];

  const popularSearches = ['ফেসওয়াশ', 'হেডফোন', 'স্নিকার্স', 'স্মার্ট ওয়াচ', 'ফ্রাইং প্যান', 'শার্ট'];

  // Instant Matching Products for Autocomplete
  const matchingProducts = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim();
    return products.filter(p => 
      p.name.toLowerCase().includes(q) || 
      p.category.toLowerCase().includes(q) ||
      (p.nameEn && p.nameEn.toLowerCase().includes(q))
    ).slice(0, 5);
  }, [searchQuery, products]);

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-slate-200">
      {/* Top Notification Announcement Bar - Clean, e-commerce focused */}
      <div className="bg-gradient-to-r from-rose-700 via-red-600 to-rose-700 text-white text-[11px] sm:text-xs py-1.5 px-4 font-medium flex items-center justify-between">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 truncate">
            <span className="bg-white/20 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 text-[10px]">
              <Sparkles className="w-3 h-3 text-amber-300" /> অফার
            </span>
            <span className="truncate">৮০০ টাকার কেনাকাটায় ফ্রি হোম ডেলিভারি! প্রোমোকোড: <strong>FREESHIP</strong></span>
          </div>

          <div className="hidden sm:flex items-center gap-4 text-[11px] shrink-0">
            <span className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5" /> দেশজুড়ে ক্যাশ অন ডেলিভারি
            </span>
            <span className="text-white/40">|</span>
            <a href="tel:09612345678" className="flex items-center gap-1 hover:text-rose-200 transition-colors">
              <PhoneCall className="w-3 h-3" /> হেল্পলাইন: ০৯৬১২-৩৪৫৬৭৮
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-3 sm:gap-6">
          
          {/* Logo & Brand */}
          <button 
            onClick={() => onSelectCategory('all')} 
            className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none shrink-0"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-white border border-rose-100 p-0.5 flex items-center justify-center shadow-sm shadow-rose-600/10 group-hover:scale-105 transition-transform overflow-hidden">
              <img 
                src="/assets/aistudio/file_00000000288c81f4911ee1105a435626_6f285ce8.png" 
                alt="জনতা মার্ট লোগো" 
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-rose-600">জনতা মার্ট</span>
                <span className="text-[10px] bg-rose-100 text-rose-700 font-bold px-1.5 py-0.5 rounded">BD</span>
              </div>
              <span className="text-[10px] text-slate-500 font-semibold tracking-wider uppercase block -mt-1 hidden sm:block">
                JANATA MART • বিশ্বস্ত শপিং
              </span>
            </div>
          </button>

          {/* Search Bar with Instant Autocomplete & Trending Searches */}
          <div className="flex-1 max-w-xl relative">
            <div className={`relative flex items-center rounded-full bg-slate-100 border transition-all ${
              isSearchFocused ? 'border-rose-500 ring-2 ring-rose-500/20 bg-white' : 'border-slate-200 hover:border-slate-300'
            }`}>
              <Search className="w-4 h-4 text-slate-400 ml-3.5 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="পণ্য, গ্যাজেট বা ব্র্যান্ড সার্চ করুন..."
                className="w-full py-2 sm:py-2.5 pl-2.5 pr-8 text-xs sm:text-sm bg-transparent border-none focus:outline-none text-slate-800 placeholder-slate-400"
              />
              {searchQuery && (
                <button 
                  onClick={() => onSearchChange('')}
                  className="mr-2 text-slate-400 hover:text-slate-600 p-1 rounded-full cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Live Autocomplete & Trending Search Dropdown */}
            {isSearchFocused && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 p-3 animate-in fade-in slide-in-from-top-2 duration-150">
                {searchQuery.trim() ? (
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2 px-1">
                      মেলা পণ্যসমূহ ({matchingProducts.length})
                    </span>
                    {matchingProducts.length === 0 ? (
                      <p className="text-xs text-slate-500 py-3 text-center">কোনো পণ্য পাওয়া যায়নি</p>
                    ) : (
                      <div className="divide-y divide-slate-100">
                        {matchingProducts.map(p => (
                          <div
                            key={p.id}
                            onMouseDown={() => {
                              if (onSelectProduct) onSelectProduct(p);
                              setIsSearchFocused(false);
                            }}
                            className="p-2 hover:bg-slate-50 rounded-xl flex items-center gap-2.5 cursor-pointer transition-colors"
                          >
                            <img src={p.img} alt={p.name} className="w-9 h-9 rounded-lg object-cover border shrink-0" />
                            <div className="flex-1 min-w-0">
                              <h4 className="text-xs font-bold text-slate-800 truncate">{p.name}</h4>
                              <span className="text-[10px] text-rose-600 font-bold">৳{toBengaliNumber(p.price)}</span>
                            </div>
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium">
                              {p.category}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2 px-1 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-rose-500" /> জনপ্রিয় সার্চসমূহ
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {popularSearches.map(tag => (
                        <button
                          key={tag}
                          type="button"
                          onMouseDown={() => onSearchChange(tag)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Actions & Utilities - ONLY Profile button */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onOpenProfile}
              className="relative flex items-center gap-2 px-3 py-2 text-slate-700 hover:text-rose-600 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all cursor-pointer shadow-sm group"
              title="গ্রাহক প্রোফাইল ও ঠিকানা"
            >
              <div className="relative w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center font-bold group-hover:bg-rose-100 transition-colors">
                <User className="w-4 h-4" />
                {currentUser && (
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 absolute -top-0.5 -right-0.5 ring-2 ring-white" />
                )}
              </div>
              <div className="text-left hidden sm:block">
                <span className="text-[10px] text-slate-400 block leading-tight">অ্যাকাউন্ট</span>
                <span className="text-xs font-bold text-slate-800 truncate max-w-[110px] block leading-tight">
                  {currentUser ? currentUser.name.split(' ')[0] : 'প্রোফাইল'}
                </span>
              </div>
            </button>
          </div>

        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-2.5 pb-1 border-t border-slate-100 mt-2 text-xs font-semibold">
          <span className="text-slate-400 text-[11px] uppercase tracking-wider shrink-0 mr-1">ক্যাটাগরি:</span>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
