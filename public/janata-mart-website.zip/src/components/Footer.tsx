import React from 'react';
import { 
  ShoppingBag, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Headphones,
  CreditCard,
  Heart
} from 'lucide-react';

interface FooterProps {
  onSelectCategory: (cat: string) => void;
  onOpenOrders: () => void;
  onToggleAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCategory,
  onOpenOrders,
  onToggleAdmin
}) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-24 sm:pb-12 border-t border-slate-800 text-xs">
      {/* 4 Trust Highlights */}
      <div className="container mx-auto px-4 mb-10 pb-8 border-b border-slate-800">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">সুপারফাস্ট ডেলিভারি</h4>
              <p className="text-[11px] text-slate-400">২৪ থেকে ৪৮ ঘণ্টায় ঘরে বসেই পান</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">১০০% আসল পণ্য</h4>
              <p className="text-[11px] text-slate-400">কোয়ালিটি ও মান যাচাইকৃত সামগ্রী</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">৭ দিনের সহজ রিটার্ন</h4>
              <p className="text-[11px] text-slate-400">সমস্যা হলে দ্রুত পরিবর্তন সুবিধা</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">২৪/৭ কাস্টমার সাপোর্ট</h4>
              <p className="text-[11px] text-slate-400">যেকোনো প্রশ্নে সরাসরি হেল্পলাইন</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
        
        {/* Brand Column */}
        <div className="space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white p-1 flex items-center justify-center shadow-md overflow-hidden">
              <img 
                src="/assets/aistudio/file_00000000288c81f4911ee1105a435626_6f285ce8.png" 
                alt="জনতা মার্ট" 
                className="w-full h-full object-contain"
              />
            </div>
            <span className="text-xl font-black text-white">জনতা মার্ট</span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            জনতা মার্ট বাংলাদেশের বিশ্বস্ত অনলাইন শপিং মল। সাশ্রয়ী দামে সেরা ইলেকট্রনিক্স, গ্যাজেট, ফ্যাশন এবং প্রসাধনী সামগ্রী কিনুন ক্যাশ অন ডেলিভারিতে।
          </p>
          <div className="pt-2 text-[11px] space-y-1 text-slate-400">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-rose-500" />
              <span>হেল্পলাইন: ০৯৬১২-৩৪৫৬৭৮ (সকাল ৯টা - রাত ১০টা)</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-rose-500" />
              <span>সহায়তা: support@janatamart.bd</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span>প্রধান কার্যালয়: গুলশান-২, ঢাকা-১২১২, বাংলাদেশ</span>
            </div>
          </div>
        </div>

        {/* Categories Column */}
        <div>
          <h4 className="font-bold text-white text-sm mb-3">জনপ্রিয় ক্যাটাগরি</h4>
          <ul className="space-y-2 text-slate-400">
            <li>
              <button onClick={() => onSelectCategory('ইলেকট্রনিক্স')} className="hover:text-rose-400 transition-colors cursor-pointer">
                ইলেকট্রনিক্স ও গ্যাজেট
              </button>
            </li>
            <li>
              <button onClick={() => onSelectCategory('ফ্যাশন')} className="hover:text-rose-400 transition-colors cursor-pointer">
                পুরুষ ও নারীদের ফ্যাশন
              </button>
            </li>
            <li>
              <button onClick={() => onSelectCategory('বিউটি')} className="hover:text-rose-400 transition-colors cursor-pointer">
                বিউটি ও স্কিন কেয়ার
              </button>
            </li>
            <li>
              <button onClick={() => onSelectCategory('কিচেন')} className="hover:text-rose-400 transition-colors cursor-pointer">
                হোম ও কিচেন আইটেম
              </button>
            </li>
            <li>
              <button onClick={() => onSelectCategory('all')} className="hover:text-rose-400 transition-colors cursor-pointer">
                সকল পণ্য ও বিশেষ অফার
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Care Column */}
        <div>
          <h4 className="font-bold text-white text-sm mb-3">গ্রাহক সেবা</h4>
          <ul className="space-y-2 text-slate-400">
            <li>
              <button onClick={onOpenOrders} className="hover:text-rose-400 transition-colors cursor-pointer">
                অর্ডার ট্র্যাকিং
              </button>
            </li>
            <li>
              <span className="hover:text-rose-400 transition-colors cursor-default">ডেলিভারি তথ্য ও চার্জ</span>
            </li>
            <li>
              <span className="hover:text-rose-400 transition-colors cursor-default">রিটার্ন ও রিফান্ড নীতিমালা</span>
            </li>
            <li>
              <span className="hover:text-rose-400 transition-colors cursor-default">গোপনীয়তা ও ব্যবহারের শর্তাবলী</span>
            </li>
            <li>
              <button onClick={onToggleAdmin} className="text-slate-500 hover:text-rose-400 transition-colors cursor-pointer">
                এডমিন লগইন
              </button>
            </li>
          </ul>
        </div>

        {/* Accepted Payment Gateways */}
        <div>
          <h4 className="font-bold text-white text-sm mb-3">নিরাপদ পেমেন্ট গেটওয়ে</h4>
          <p className="text-[11px] text-slate-400 mb-3">
            আমরা বাংলাদেশ ব্যাংক অনুমোদিত সকল প্রধান মোবাইল ফিন্যান্সিয়াল ও কার্ড পেমেন্ট সমর্থন করি:
          </p>

          <div className="grid grid-cols-2 gap-2 text-[11px] font-bold">
            <div className="p-2 bg-slate-800 rounded-lg flex items-center gap-2 text-pink-400">
              <span className="w-5 h-5 rounded-full bg-[#E2136E] text-white flex items-center justify-center text-[10px]">b</span>
              <span>বিকাশ (bKash)</span>
            </div>
            <div className="p-2 bg-slate-800 rounded-lg flex items-center gap-2 text-orange-400">
              <span className="w-5 h-5 rounded-full bg-[#F7941D] text-white flex items-center justify-center text-[10px]">ন</span>
              <span>নগদ (Nagad)</span>
            </div>
            <div className="p-2 bg-slate-800 rounded-lg flex items-center gap-2 text-purple-400">
              <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px]">R</span>
              <span>রকেট (DBBL)</span>
            </div>
            <div className="p-2 bg-slate-800 rounded-lg flex items-center gap-2 text-blue-400">
              <CreditCard className="w-4 h-4 text-blue-400" />
              <span>কার্ড / ভিসা</span>
            </div>
          </div>
          
          <div className="mt-3 text-[11px] text-emerald-400 font-semibold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>256-Bit SSL এনক্রিপ্টেড পেমেন্ট প্রটেকশন</span>
          </div>
        </div>

      </div>

      {/* Copyright Bar */}
      <div className="container mx-auto px-4 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2 text-center sm:text-left">
        <div>
          © {new Date().getFullYear()} জনতা মার্ট (Janata Mart) বাংলাদেশ। সর্বস্বত্ব সংরক্ষিত।
        </div>
        <div className="flex items-center gap-1">
          <span>মেড উইথ</span>
          <Heart className="w-3 h-3 text-rose-500 fill-rose-500 inline" />
          <span>ফর বাংলাদেশি অনলাইন ক্রেতারা</span>
        </div>
      </div>
    </footer>
  );
};
