/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Truck, 
  Banknote, 
  ShieldCheck, 
  Flame, 
  SlidersHorizontal,
  ChevronDown,
  ShoppingBag,
  CheckCircle,
  Zap,
  Headphones,
  RotateCcw
} from 'lucide-react';

import { Product, CartItem, Order, UserProfile, PaymentMethod, PaymentDetails, Review } from './types';
import { INITIAL_PRODUCTS, AVAILABLE_COUPONS, toBengaliNumber, playSound } from './data/bangladeshData';

import { Header } from './components/Header';
import { ProductCard } from './components/ProductCard';
import { ProductDetailView } from './components/ProductDetailView';
import { CartCheckoutModal } from './components/CartCheckoutModal';
import { PaymentGatewayModal } from './components/PaymentGatewayModal';
import { OrderConfirmationModal } from './components/OrderConfirmationModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { UserProfileModal } from './components/UserProfileModal';
import { WishlistModal } from './components/WishlistModal';
import { AdminPanel } from './components/AdminPanel';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { SeoHead } from './components/SeoHead';

export default function App() {
  // Persistence state
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('jm_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('jm_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('jm_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('jm_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('jm_user');
      return saved ? JSON.parse(saved) : {
        name: 'তানভীর আহমেদ',
        phone: '01711002233',
        division: 'ঢাকা',
        district: 'ঢাকা সদর',
        upazila: 'মিরপুর',
        address: 'বাড়ি ১২, রোড ৪, ব্লক সি',
        email: 'tanveer@example.com'
      };
    } catch {
      return null;
    }
  });

  // Views & Modals
  const [activeView, setActiveView] = useState<'store' | 'pdp' | 'admin'>('store');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [latestOrder, setLatestOrder] = useState<Order | null>(null);
  const [trackOrderId, setTrackOrderId] = useState<string>('');

  // Payment Gateway Pending State
  const [isGatewayOpen, setIsGatewayOpen] = useState(false);
  const [pendingOrderData, setPendingOrderData] = useState<{
    name: string;
    phone: string;
    division: string;
    district: string;
    upazila: string;
    address: string;
    paymentMethod: PaymentMethod;
    subtotal: number;
    deliveryCharge: number;
    discount: number;
    couponCode?: string;
    total: number;
  } | null>(null);

  // Filters, Tags & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filterTag, setFilterTag] = useState<'all' | 'discount' | 'topRated' | 'inStock'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'priceLow' | 'priceHigh' | 'rating'>('featured');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Flash Sale Live Countdown Timer (Seconds left for today)
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number }>({
    hours: 7,
    minutes: 42,
    seconds: 15
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: 59, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 12, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const productsSectionRef = useRef<HTMLDivElement>(null);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('jm_products', JSON.stringify(products));
    } catch {}
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('jm_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('jm_wishlist', JSON.stringify(wishlist));
    } catch {}
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem('jm_orders', JSON.stringify(orders));
    } catch {}
  }, [orders]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem('jm_user', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('jm_user');
      }
    } catch {}
  }, [currentUser]);

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => prev === msg ? null : prev);
    }, 2800);
  };

  // Cart operations with variant handling
  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.qty, 0), [cart]);
  const cartTotal = useMemo(() => cart.reduce((acc, item) => acc + item.price * item.qty, 0), [cart]);

  const handleAddToCart = (
    product: Product, 
    quantity = 1, 
    variant?: { color?: string; size?: string }
  ) => {
    const targetColor = variant?.color || (product.variants?.colors?.[0] ?? undefined);
    const targetSize = variant?.size || (product.variants?.sizes?.[0] ?? undefined);

    setCart(prev => {
      const existing = prev.find(i => 
        i.id === product.id && 
        i.selectedColor === targetColor && 
        i.selectedSize === targetSize
      );
      if (existing) {
        return prev.map(i => 
          (i.id === product.id && i.selectedColor === targetColor && i.selectedSize === targetSize)
            ? { ...i, qty: i.qty + quantity } 
            : i
        );
      }
      return [...prev, { 
        ...product, 
        qty: quantity,
        selectedColor: targetColor,
        selectedSize: targetSize
      }];
    });
    playSound('pop');
    showToast(`'${product.name}' কার্টে যুক্ত করা হয়েছে!`);
  };

  const handleUpdateQty = (productId: number, delta: number, color?: string, size?: string) => {
    setCart(prev => {
      return prev
        .map(i => {
          if (i.id === productId && (!color || i.selectedColor === color) && (!size || i.selectedSize === size)) {
            const nextQty = i.qty + delta;
            return nextQty > 0 ? { ...i, qty: nextQty } : null;
          }
          return i;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveItem = (productId: number, color?: string, size?: string) => {
    setCart(prev => prev.filter(i => !(i.id === productId && (!color || i.selectedColor === color) && (!size || i.selectedSize === size))));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Wishlist toggle
  const handleToggleWishlist = (productId: number) => {
    setWishlist(prev => {
      if (prev.includes(productId)) {
        playSound('pop');
        showToast('পছন্দের তালিকা থেকে সরানো হয়েছে');
        return prev.filter(id => id !== productId);
      } else {
        playSound('success');
        showToast('পছন্দের তালিকায় যোগ করা হয়েছে ❤️');
        return [...prev, productId];
      }
    });
  };

  // PDP Handlers
  const handleOpenDetails = (product: Product) => {
    setSelectedProduct(product);
    setActiveView('pdp');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBuyNow = (
    product: Product, 
    quantity = 1, 
    variant?: { color?: string; size?: string }
  ) => {
    handleAddToCart(product, quantity, variant);
    setIsCartOpen(true);
  };

  const handleAddReview = (productId: number, review: Omit<Review, 'id' | 'date'>) => {
    const newRev: Review = {
      id: 'rev_' + Date.now(),
      date: new Date().toLocaleDateString('bn-BD'),
      ...review
    };

    setProducts(prev => prev.map(p => {
      if (p.id === productId) {
        const nextReviews = [newRev, ...p.reviews];
        const avg = +(nextReviews.reduce((sum, r) => sum + r.rating, 0) / nextReviews.length).toFixed(1);
        return {
          ...p,
          reviews: nextReviews,
          reviewsCount: nextReviews.length,
          rating: avg
        };
      }
      return p;
    }));

    if (selectedProduct && selectedProduct.id === productId) {
      setSelectedProduct(prev => prev ? {
        ...prev,
        reviews: [newRev, ...prev.reviews],
        reviewsCount: prev.reviews.length + 1
      } : null);
    }
  };

  // Checkout Flow
  const handleProceedToPayment = (orderData: {
    name: string;
    phone: string;
    division: string;
    district: string;
    upazila: string;
    address: string;
    paymentMethod: PaymentMethod;
    subtotal: number;
    deliveryCharge: number;
    discount: number;
    couponCode?: string;
    total: number;
  }) => {
    setPendingOrderData(orderData);
    setIsCartOpen(false);

    if (orderData.paymentMethod === 'COD') {
      // Instant Cash on Delivery confirmation
      finalizeOrder(orderData, {
        method: 'COD',
        status: 'PENDING'
      });
    } else {
      // Open Gateway Modal for bKash, Nagad, Rocket or Card
      setIsGatewayOpen(true);
    }
  };

  const handlePaymentSuccess = (paymentDetails: PaymentDetails) => {
    if (!pendingOrderData) return;
    setIsGatewayOpen(false);
    finalizeOrder(pendingOrderData, paymentDetails);
  };

  const finalizeOrder = (
    orderData: NonNullable<typeof pendingOrderData>, 
    paymentDetails: PaymentDetails
  ) => {
    const randomNum = Math.floor(100000 + Math.random() * 900000);
    const newOrder: Order = {
      orderId: `JM-${randomNum}`,
      date: new Date().toLocaleDateString('bn-BD'),
      timestamp: Date.now(),
      name: orderData.name,
      phone: orderData.phone,
      location: `${orderData.upazila}, ${orderData.district}, ${orderData.division}`,
      division: orderData.division,
      district: orderData.district,
      upazila: orderData.upazila,
      address: orderData.address,
      paymentDetails,
      items: [...cart],
      subtotal: orderData.subtotal,
      deliveryCharge: orderData.deliveryCharge,
      discount: orderData.discount,
      couponCode: orderData.couponCode,
      total: orderData.total,
      status: 'পেন্ডিং',
      deliveryEstimatedDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toLocaleDateString('bn-BD')
    };

    setOrders(prev => [newOrder, ...prev]);
    setLatestOrder(newOrder);
    setCart([]);
    setPendingOrderData(null);
    setIsConfirmationOpen(true);
  };

  // Filter & Sort Products
  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (selectedCategory !== 'all') {
      result = result.filter(p => p.category === selectedCategory);
    }

    if (filterTag === 'discount') {
      result = result.filter(p => p.oldPrice && p.oldPrice > p.price);
    } else if (filterTag === 'topRated') {
      result = result.filter(p => p.rating >= 4.7);
    } else if (filterTag === 'inStock') {
      result = result.filter(p => p.stock > 0);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.category.toLowerCase().includes(q) ||
        (p.nameEn && p.nameEn.toLowerCase().includes(q))
      );
    }

    if (sortBy === 'priceLow') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'priceHigh') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [products, selectedCategory, filterTag, searchQuery, sortBy]);

  const scrollToProducts = () => {
    setActiveView('store');
    setTimeout(() => {
      productsSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // Admin Actions
  const handleAddProductAdmin = (newProductData: Omit<Product, 'id' | 'rating' | 'reviewsCount' | 'reviews'>) => {
    const newP: Product = {
      ...newProductData,
      id: Date.now(),
      rating: 5.0,
      reviewsCount: 1,
      reviews: []
    };
    setProducts(prev => [newP, ...prev]);
    showToast('নতুন পণ্য স্টোরে যোগ করা হয়েছে!');
  };

  const handleDeleteProductAdmin = (id: number) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    showToast('পণ্যটি মুছে ফেলা হয়েছে!');
  };

  const handleUpdateStockAdmin = (id: number, newStock: number) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, stock: newStock } : p));
  };

  const handleUpdateOrderStatusAdmin = (orderId: string, status: Order['status']) => {
    setOrders(prev => prev.map(o => o.orderId === orderId ? { ...o, status } : o));
    showToast(`অর্ডার #${orderId} এর স্ট্যাটাস '${status}' করা হয়েছে।`);
  };

  const handleResetData = () => {
    setProducts(INITIAL_PRODUCTS);
    setOrders([]);
    showToast('ডেমো ডেটা রিসেট সফল হয়েছে।');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f6f7fb]">
      
      {/* SEO Engine */}
      <SeoHead 
        product={activeView === 'pdp' ? selectedProduct : null} 
        category={selectedCategory} 
      />

      {/* Global Toast Alert */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 backdrop-blur-md text-white px-5 py-2.5 rounded-full shadow-2xl text-xs sm:text-sm font-semibold flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main App Navigation Header */}
      {activeView !== 'admin' && (
        <Header
          currentUser={currentUser}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onOpenProfile={() => setIsProfileOpen(true)}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            if (activeView !== 'store') setActiveView('store');
            scrollToProducts();
          }}
          selectedCategory={selectedCategory}
          products={products}
          onSelectProduct={handleOpenDetails}
        />
      )}

      {/* ========================================================
          VIEW 1: STORE FRONT / HOME PAGE
          ======================================================== */}
      {activeView === 'store' && (
        <main className="flex-1 pb-16">
          <div className="container mx-auto px-4 py-4 sm:py-6 max-w-7xl">
            
            {/* HERO BANNER SECTION */}
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-slate-950 via-red-950 to-slate-900 text-white mb-8 shadow-xl">
              <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#e11d48_1px,transparent_1px)] [background-size:16px_16px]" />
              
              <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-6 items-center p-6 sm:p-10 lg:p-12">
                <div className="space-y-4 max-w-xl">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold">
                    <Flame className="w-3.5 h-3.5 text-rose-400" />
                    সেরা উৎসব অফার চলছে
                  </div>

                  <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black leading-tight tracking-tight">
                    সবার পছন্দের সেরা পণ্য <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-amber-300">
                      এখন এক জায়গায়!
                    </span>
                  </h1>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    স্মার্ট গ্যাজেট, ট্রেন্ডি ফ্যাশন আর কিচেনের দরকারি সব জিনিস — দেশজুড়ে দ্রুত ডেলিভারি ও সুরক্ষিত পেমেন্টে অর্ডার করুন এখনই।
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      onClick={scrollToProducts}
                      className="px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-black text-xs sm:text-sm shadow-lg shadow-rose-600/30 flex items-center gap-2 transition-all hover:scale-105 cursor-pointer"
                    >
                      <span>এখনই শপিং শুরু করুন</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        setSelectedCategory('ইলেকট্রনিক্স');
                        scrollToProducts();
                      }}
                      className="px-5 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm backdrop-blur-sm border border-white/10 transition-colors cursor-pointer"
                    >
                      গ্যাজেট ডিল দেখুন
                    </button>
                  </div>
                </div>

                {/* Hero Graphic Card Showcase */}
                <div className="hidden md:flex justify-center">
                  <div className="relative w-80 h-72 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/10 group">
                    <img 
                      src="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80" 
                      alt="Janata Mart Showcase" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-5">
                      <span className="text-xs font-bold text-amber-300">স্পেশাল কালেকশন</span>
                      <h3 className="text-base font-bold text-white">প্রিমিয়াম ওয়্যারলেস অডিও ও ঘড়ি</h3>
                      <p className="text-[11px] text-slate-300">৪০% পর্যন্ত আকর্ষণীয় ক্যাশব্যাক অফার</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 3 Key Trust Highlights Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-8">
              <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3.5 hover:border-rose-300 transition-colors">
                <div className="w-11 h-11 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">দ্রুত ডেলিভারি</h4>
                  <p className="text-[11px] text-slate-500">ঢাকার ভেতর ২৪ ঘণ্টা ও দেশজুড়ে ৪৮ ঘণ্টা</p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3.5 hover:border-rose-300 transition-colors">
                <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Banknote className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">ক্যাশ অন ডেলিভারি</h4>
                  <p className="text-[11px] text-slate-500">পণ্য হাতে পেয়ে পরীক্ষা করে টাকা দিন</p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3.5 hover:border-rose-300 transition-colors">
                <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">১০০% আসল পণ্য</h4>
                  <p className="text-[11px] text-slate-500">৭ দিনের সহজ রিটার্ন ও এক্সচেঞ্জ নিশ্চয়তা</p>
                </div>
              </div>
            </div>

            {/* FLASH SALE LIVE COUNTDOWN BANNER */}
            <div className="mb-8 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-600 to-red-600 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white shrink-0">
                  <Zap className="w-6 h-6 text-amber-200 fill-amber-200" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-black/25 px-2 py-0.5 rounded">
                      ফ্ল্যাশ ডিল
                    </span>
                    <span className="text-xs text-amber-200 font-bold">সীমিত সময়ের অফার</span>
                  </div>
                  <h3 className="text-sm sm:text-base font-black">আজকের সেরা কেনাকাটায় বিশেষ ছাড় ও ফ্রি গিফট!</h3>
                </div>
              </div>

              {/* Countdown Digits */}
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-bold text-white/90 hidden sm:inline">অফার শেষ হতে বাকি:</span>
                <div className="flex items-center gap-1.5 text-center">
                  <div className="bg-slate-950/80 px-2.5 py-1 rounded-lg">
                    <span className="text-sm sm:text-base font-black text-amber-300 font-mono">
                      {toBengaliNumber(String(timeLeft.hours).padStart(2, '0'))}
                    </span>
                    <span className="block text-[9px] text-slate-300">ঘণ্টা</span>
                  </div>
                  <span className="font-black text-white">:</span>
                  <div className="bg-slate-950/80 px-2.5 py-1 rounded-lg">
                    <span className="text-sm sm:text-base font-black text-amber-300 font-mono">
                      {toBengaliNumber(String(timeLeft.minutes).padStart(2, '0'))}
                    </span>
                    <span className="block text-[9px] text-slate-300">মিনিট</span>
                  </div>
                  <span className="font-black text-white">:</span>
                  <div className="bg-slate-950/80 px-2.5 py-1 rounded-lg">
                    <span className="text-sm sm:text-base font-black text-amber-300 font-mono">
                      {toBengaliNumber(String(timeLeft.seconds).padStart(2, '0'))}
                    </span>
                    <span className="block text-[9px] text-slate-300">সেকেন্ড</span>
                  </div>
                </div>
              </div>
            </div>

            {/* CATEGORIES CARD GRID */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-slate-900">ক্যাটাগরি সমূহ</h2>
                  <p className="text-xs text-slate-500">আপনার প্রয়োজনীয় বিভাগ বেছে নিন</p>
                </div>
                <button
                  onClick={() => setSelectedCategory('all')}
                  className="text-xs font-bold text-rose-600 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  সব দেখুন <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                {[
                  { name: 'ইলেকট্রনিক্স', count: 'গ্যাজেট ও হেডফোন', img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80' },
                  { name: 'ফ্যাশন', count: 'পোশাক ও স্নিকার্স', img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80' },
                  { name: 'কিচেন', count: 'ফ্রাইপ্যান ও ব্লেন্ডার', img: 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=400&q=80' },
                  { name: 'বিউটি', count: 'ফেসওয়াশ ও তেল', img: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&q=80' }
                ].map(cat => (
                  <div
                    key={cat.name}
                    onClick={() => {
                      setSelectedCategory(cat.name);
                      scrollToProducts();
                    }}
                    className={`group p-3 sm:p-4 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 bg-white ${
                      selectedCategory === cat.name 
                        ? 'border-rose-600 ring-2 ring-rose-500/20 bg-rose-50/30' 
                        : 'border-slate-200 hover:border-slate-300 hover:shadow-md'
                    }`}
                  >
                    <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 shrink-0">
                      <img src={cat.img} alt={cat.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-800 group-hover:text-rose-600 transition-colors">
                        {cat.name}
                      </h4>
                      <span className="text-[10px] text-slate-400 block">{cat.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* PRODUCTS LISTING & CONTROLS */}
            <div ref={productsSectionRef} className="pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 border-b border-slate-200 pb-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
                    <span>
                      {selectedCategory === 'all' ? 'সকল পণ্য' : `${selectedCategory} কালেকশন`}
                    </span>
                    <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full">
                      {toBengaliNumber(filteredProducts.length)}টি পণ্য
                    </span>
                  </h2>
                  {searchQuery && (
                    <p className="text-xs text-slate-500 mt-1">
                      অনুসন্ধান: &ldquo;{searchQuery}&rdquo; এর ফলাফল
                    </p>
                  )}
                </div>

                {/* Filter tags & Sort dropdown */}
                <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                  <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
                    <button
                      onClick={() => setFilterTag('all')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        filterTag === 'all' 
                          ? 'bg-white text-rose-600 shadow-sm' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      সব
                    </button>
                    <button
                      onClick={() => setFilterTag('discount')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        filterTag === 'discount' 
                          ? 'bg-rose-600 text-white shadow-sm' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      🔥 ছাড় অফার
                    </button>
                    <button
                      onClick={() => setFilterTag('topRated')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        filterTag === 'topRated' 
                          ? 'bg-amber-500 text-white shadow-sm' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      ⭐ সেরা রেটিং
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <SlidersHorizontal className="w-4 h-4 text-slate-400" />
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-rose-500 cursor-pointer"
                    >
                      <option value="featured">সেরা পছন্দ</option>
                      <option value="priceLow">দাম: কম ➔ বেশি</option>
                      <option value="priceHigh">দাম: বেশি ➔ কম</option>
                      <option value="rating">সর্বোচ্চ রেটিং</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Product Grid */}
              {filteredProducts.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-3xl border border-slate-200 p-8 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h3 className="text-base font-bold text-slate-800">কোনো পণ্য পাওয়া যায়নি!</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    আপনার সার্চ কীওয়ার্ড পরিবর্তন করে আবার চেষ্টা করুন অথবা সব ক্যাটাগরি ব্রাউজ করুন।
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                    }}
                    className="px-5 py-2 rounded-xl bg-rose-600 text-white font-bold text-xs shadow transition-colors cursor-pointer"
                  >
                    সব পণ্য দেখুন
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
                  {filteredProducts.map(product => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      isWished={wishlist.includes(product.id)}
                      onToggleWishlist={handleToggleWishlist}
                      onAddToCart={(p) => handleAddToCart(p, 1)}
                      onOpenDetails={handleOpenDetails}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* PROMOTIONAL VALUE BANNER */}
            <div className="mt-12 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-red-600 to-rose-700 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
              <div className="space-y-1 text-center sm:text-left">
                <span className="inline-block bg-white/20 text-white text-[11px] font-bold px-3 py-0.5 rounded-full mb-1">
                  🎁 স্পেশাল কুপন কোড
                </span>
                <h3 className="text-xl sm:text-2xl font-black">প্রথম অর্ডারে ফ্ল্যাট ১০% ডিসকাউন্ট!</h3>
                <p className="text-xs text-rose-100">
                  চেকআউট করার সময় প্রোমোকোড বক্সটিতে <strong>JANATA10</strong> ব্যবহার করুন।
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedCategory('all');
                  scrollToProducts();
                }}
                className="px-6 py-3 rounded-2xl bg-white text-rose-700 hover:bg-rose-50 font-black text-xs sm:text-sm shadow-md transition-transform hover:scale-105 shrink-0 cursor-pointer"
              >
                এখনই উপভোগ করুন
              </button>
            </div>

          </div>
        </main>
      )}

      {/* ========================================================
          VIEW 2: PRODUCT DETAIL PAGE (PDP)
          ======================================================== */}
      {activeView === 'pdp' && selectedProduct && (
        <main className="flex-1 pb-16">
          <ProductDetailView
            product={selectedProduct}
            allProducts={products}
            isWished={wishlist.includes(selectedProduct.id)}
            onBack={() => {
              setActiveView('store');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onToggleWishlist={handleToggleWishlist}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
            onAddReview={handleAddReview}
            onSelectProduct={handleOpenDetails}
          />
        </main>
      )}

      {/* ========================================================
          VIEW 3: ADMIN CONTROL PANEL
          ======================================================== */}
      {activeView === 'admin' && (
        <main className="flex-1">
          <AdminPanel
            products={products}
            orders={orders}
            coupons={AVAILABLE_COUPONS}
            onBackToStore={() => setActiveView('store')}
            onAddProduct={handleAddProductAdmin}
            onDeleteProduct={handleDeleteProductAdmin}
            onUpdateStock={handleUpdateStockAdmin}
            onUpdateOrderStatus={handleUpdateOrderStatusAdmin}
            onResetData={handleResetData}
          />
        </main>
      )}

      {/* ========================================================
          MODALS & SYSTEM DIALOGS
          ======================================================== */}
      
      {/* 1. Cart & Checkout Modal */}
      <CartCheckoutModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        currentUser={currentUser}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToPayment={handleProceedToPayment}
      />

      {/* 2. Real Interactive Payment Gateway Modal */}
      {pendingOrderData && (
        <PaymentGatewayModal
          isOpen={isGatewayOpen}
          onClose={() => setIsGatewayOpen(false)}
          method={pendingOrderData.paymentMethod}
          amount={pendingOrderData.total}
          orderNumber={`JM-${Math.floor(100000 + Math.random() * 900000)}`}
          customerPhone={pendingOrderData.phone}
          customerName={pendingOrderData.name}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* 3. Order Confirmation & Printable Invoice Modal */}
      <OrderConfirmationModal
        isOpen={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
        order={latestOrder}
        onTrackOrder={(orderId) => {
          setTrackOrderId(orderId);
          setIsOrdersOpen(true);
        }}
      />

      {/* 4. Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={isOrdersOpen}
        onClose={() => setIsOrdersOpen(false)}
        orders={orders}
        defaultOrderId={trackOrderId}
        onCancelOrder={(id) => handleUpdateOrderStatusAdmin(id, 'বাতিল')}
      />

      {/* 5. User Profile & Address Modal */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        currentUser={currentUser}
        onSaveProfile={(prof) => {
          setCurrentUser(prof);
          showToast('প্রোফাইল তথ্য আপডেট সম্পন্ন!');
        }}
        onLogout={() => {
          setCurrentUser(null);
          showToast('লগআউট করা হয়েছে!');
        }}
        onOpenOrders={() => setIsOrdersOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        cartCount={cartCount}
        wishlistCount={wishlist.length}
      />

      {/* 6. Wishlist Modal */}
      <WishlistModal
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistIds={wishlist}
        allProducts={products}
        onRemoveFromWishlist={handleToggleWishlist}
        onAddToCart={(p) => handleAddToCart(p, 1)}
        onOpenDetails={handleOpenDetails}
      />

      {/* Floating Desktop Quick Cart Launcher */}
      {activeView !== 'admin' && cartCount > 0 && (
        <button
          onClick={() => {
            playSound('pop');
            setIsCartOpen(true);
          }}
          className="fixed bottom-6 right-6 z-40 hidden md:flex items-center gap-3 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white pl-4 pr-5 py-3.5 rounded-full shadow-2xl hover:shadow-rose-600/40 hover:scale-105 active:scale-95 transition-all cursor-pointer border border-white/20 animate-bounce duration-1000"
          title="আপনার শপিং কার্ট দেখুন"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5" />
            <span className="absolute -top-2 -right-2 bg-amber-400 text-slate-950 text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center ring-2 ring-white">
              {toBengaliNumber(cartCount)}
            </span>
          </div>
          <div className="text-left">
            <span className="text-[10px] text-rose-100 block font-medium leading-none">কার্ট</span>
            <span className="text-sm font-black tracking-tight leading-tight">৳{toBengaliNumber(cartTotal)}</span>
          </div>
        </button>
      )}

      {/* Floating WhatsApp Live Helpline */}
      {activeView !== 'admin' && (
        <a
          href="https://wa.me/8801711002233?text=আসসালামু%20আলাইকুম,%20জনতা%20মার্ট%20থেকে%20পণ্য%20সম্পর্কে%20জানতে%20চাই"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 left-6 z-40 hidden sm:flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2.5 rounded-full shadow-xl hover:scale-105 transition-all text-xs font-bold cursor-pointer border border-emerald-400/30"
          title="হোয়াটসঅ্যাপে সরাসরি সহায়তা নিন"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
          </span>
          <span>লাইভ সাপোর্ট (WhatsApp)</span>
        </a>
      )}

      {/* Bottom Mobile Bar */}
      {activeView !== 'admin' && (
        <BottomNav
          activeTab={activeView === 'store' ? 'home' : 'categories'}
          cartCount={cartCount}
          wishlistCount={wishlist.length}
          onGoHome={() => {
            setActiveView('store');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onScrollToCategories={scrollToProducts}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenWishlist={() => setIsWishlistOpen(true)}
          onOpenOrders={() => setIsOrdersOpen(true)}
        />
      )}

      {/* Desktop & Mobile Responsive Footer */}
      {activeView !== 'admin' && (
        <Footer
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            scrollToProducts();
          }}
          onOpenOrders={() => setIsOrdersOpen(true)}
          onToggleAdmin={() => setActiveView('admin')}
        />
      )}

    </div>
  );
}
