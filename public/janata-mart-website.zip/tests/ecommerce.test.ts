import test from 'node:test';
import assert from 'node:assert';
import { toBengaliNumber } from '../src/data/bangladeshData.ts';

test('Bengali number conversion works accurately', () => {
  assert.strictEqual(toBengaliNumber(0), '০');
  assert.strictEqual(toBengaliNumber(12345), '১২৩৪৫');
  assert.strictEqual(toBengaliNumber(67890), '৬৭৮৯০');
});

test('Delivery charge calculation logic', () => {
  const calculateDelivery = (district: string, division: string, subtotal: number, couponCode?: string) => {
    if (couponCode === 'FREESHIP' || subtotal >= 2000) return 0;
    if (district === 'ঢাকা' || district === 'ঢাকা সদর') return 70;
    if (division === 'ঢাকা') return 100;
    return 130;
  };

  assert.strictEqual(calculateDelivery('ঢাকা', 'ঢাকা', 500), 70);
  assert.strictEqual(calculateDelivery('ঢাকা সদর', 'ঢাকা', 500), 70);
  assert.strictEqual(calculateDelivery('গাজীপুর', 'ঢাকা', 500), 100);
  assert.strictEqual(calculateDelivery('চট্টগ্রাম', 'চট্টগ্রাম', 500), 130);
  assert.strictEqual(calculateDelivery('চট্টগ্রাম', 'চট্টগ্রাম', 2500), 0); // over 2000 free
  assert.strictEqual(calculateDelivery('চট্টগ্রাম', 'চট্টগ্রাম', 900, 'FREESHIP'), 0); // coupon free
});

test('Coupon discount deduction logic', () => {
  const applyCoupon = (subtotal: number, code: string) => {
    if (code === 'JANATA10' && subtotal >= 500) {
      return Math.round((subtotal * 10) / 100);
    }
    if (code === 'NEW50' && subtotal >= 300) {
      return 50;
    }
    return 0;
  };

  assert.strictEqual(applyCoupon(1000, 'JANATA10'), 100);
  assert.strictEqual(applyCoupon(400, 'JANATA10'), 0); // below minSpend
  assert.strictEqual(applyCoupon(600, 'NEW50'), 50);
});
